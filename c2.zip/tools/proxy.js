const https = require("https")
const http = require("http")
const fs = require("fs")
const path = require("path")

const sources = [

    // Proxyscrape v4
    "https://api.proxyscrape.com/v4/free-proxy-list/get?request=displayproxies&protocol=http&timeout=1000&country=all&ssl=all&anonymity=all&skip=0&limit=2000",

    // Proxyscrape v2
    "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=1000&country=all",

    // RAW sources
    "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt",
    "https://raw.githubusercontent.com/iamthebestm85/Proxy-Scraper-And-Checker/main/proxy.txt",
    "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
    "https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt",
    "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt",
    "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
    "https://raw.githubusercontent.com/RX4096/proxy-list/main/online/http.txt",
    "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt",
    "https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt",
    "https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/proxies.txt",
    "https://raw.githubusercontent.com/proxy4parsing/proxy-list/main/http.txt",
    "https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt",
    "https://raw.githubusercontent.com/mertguvencli/http-proxy-list/main/proxy-list/data.txt",
    "https://raw.githubusercontent.com/hendrikbgr/Free-Proxy-Repo/master/proxy_list.txt",
    "https://raw.githubusercontent.com/almroot/proxylist/master/list.txt",
    "https://www.proxy-list.download/api/v1/get?type=http",
    "https://www.proxyscan.io/download?type=http",
    "https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/http.txt",
    "https://raw.githubusercontent.com/UptimerBot/proxy-list/main/proxies/http.txt",
    "https://api.openproxylist.xyz/http.txt",
    "https://cyber-hub.pw/statics/proxy.txt"
]

function fetchURL(url) {
    return new Promise(resolve => {

        const lib = url.startsWith("https") ? https : http

        lib.get(url, res => {

            let data = ""

            res.on("data", chunk => data += chunk)
            res.on("end", () => resolve(data))

        }).on("error", () => resolve(""))

    })
}

(async () => {

    let allRaw = ""

    for (let url of sources) {
        const data = await fetchURL(url)
        allRaw += data + "\n"
    }

    const rawList = allRaw.split(/\r?\n/)

    const proxyRegex = /^\d{1,3}(\.\d{1,3}){3}:\d+$/

    const filtered = rawList.filter(line => proxyRegex.test(line.trim()))

    const unique = [...new Set(filtered)]

    const savePath = path.join(__dirname, "proxy.txt")

    fs.writeFileSync(savePath, unique.join("\n"))

    console.log(JSON.stringify({
        totalRaw: rawList.length,
        totalUnique: unique.length
    }))

})()