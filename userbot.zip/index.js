// index.js

const { TelegramClient } = require("telegram");
const { StringSession } = require("telegram/sessions");
const { NewMessage } = require("telegram/events");
const input = require("input");
const fs = require("fs");
const path = require("path");
const config = require("./config");

const sessionPath = path.join(__dirname, "session.txt");

const stringSession = new StringSession(
    fs.existsSync(sessionPath)
        ? fs.readFileSync(sessionPath, "utf8")
        : ""
);

// ===== STABLE CLIENT CONFIG =====
const client = new TelegramClient(
    stringSession,
    config.api_id,
    config.api_hash,
    {
        connectionRetries: Infinity,
        autoReconnect: true,
        useWSS: true,
        timeout: 60000,
        retryDelay: 5000,
        floodSleepThreshold: 60,
        deviceModel: "iPhone 15 Pro",
        systemVersion: "iOS 17.0",
        appVersion: "10.0.1"
    }
);

global.runningProcesses = [];

async function startBot() {
    try {
        await client.start({
            phoneNumber: async () => await input.text("Phone number: "),
            password: async () => await input.text("2FA password (if any): "),
            phoneCode: async () => await input.text("Code: "),
            onError: (err) => console.log("Auth Error:", err)
        });

        fs.writeFileSync(sessionPath, client.session.save());
        console.log("Userbot started ✅");

        // ===== KEEP ALIVE =====
        setInterval(async () => {
            try {
                await client.getMe();
            } catch (e) {
                console.log("KeepAlive error:", e.message);
            }
        }, 60 * 1000);

        // ===== BOT API STYLE ADAPTER =====
        const bot = {

            onText: (regex, callback) => {
                client.addEventHandler(async (event) => {
                    try {
                        const text = event.message.message;
                        if (!text) return;

                        const match = text.match(regex);
                        if (!match) return;

                        const sender = await event.message.getSender();
                        const senderId = Number(sender.id.valueOf());

                        const msg = {
                            message_id: event.message.id,
                            chat: { id: event.message.chatId },
                            from: { id: senderId },
                            text: text
                        };

                        callback(msg, match);

                    } catch (err) {
                        console.log("Handler error:", err.message);
                    }
                }, new NewMessage({ outgoing: true }));
            },

            sendMessage: async (chatId, text, options = {}) => {
                return client.sendMessage(chatId, {
                    message: text,
                    parseMode: options.parse_mode || undefined
                });
            },

            reply: async (chatId, text, replyToMessageId, options = {}) => {
                return client.sendMessage(chatId, {
                    message: text,
                    replyTo: replyToMessageId,
                    parseMode: options.parse_mode || undefined
                });
            },

            editMessageText: async (chatId, messageId, text) => {
                return client.editMessage(chatId, {
                    message: messageId,
                    text: text
                });
            },

            sendFile: async (chatId, file, options = {}) => {
                return client.sendFile(chatId, {
                    file: file,
                    caption: options.caption || ""
                });
            },

            sendVideo: async (chatId, video, options = {}) => {
                return client.sendFile(chatId, {
                    file: video,
                    caption: options.caption || "",
                    supportsStreaming: true
                });
            },

            deleteMessage: async (chatId, messageId) => {
                return client.deleteMessages(chatId, [messageId]);
            },

            isOwner: (userId) => {
                return Number(userId) === Number(config.ownerId);
            }
        };

        // ===== LOAD PLUGINS =====
        const pluginsDir = path.join(__dirname, "plugins");

        if (!fs.existsSync(pluginsDir)) {
            fs.mkdirSync(pluginsDir);
        }

        fs.readdirSync(pluginsDir).forEach(file => {
            if (file.endsWith(".js")) {
                try {
                    require(path.join(pluginsDir, file))(bot);
                    console.log("Loaded plugin:", file);
                } catch (err) {
                    console.log("Plugin load error:", file, err.message);
                }
            }
        });

        console.log("All plugins loaded ✅");

    } catch (err) {
        console.log("Startup failed:", err.message);
        setTimeout(startBot, 10000);
    }
}

// ===== CRASH GUARD =====
process.on("uncaughtException", (err) => {
    console.log("Uncaught Exception:", err);
});

process.on("unhandledRejection", (err) => {
    console.log("Unhandled Rejection:", err);
});

startBot();