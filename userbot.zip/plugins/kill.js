const config = require("../config");

module.exports = (bot) => {

    if (!global.runningProcesses) global.runningProcesses = [];

    bot.onText(/\/kill/, async (msg) => {

        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (userId !== config.ownerId)
            return bot.sendMessage(chatId, "Access denied.");

        if (global.runningProcesses.length === 0)
            return bot.sendMessage(chatId, "Tidak ada proses yang berjalan.");

        // Hentikan semua process
        global.runningProcesses.forEach(proc => {
            try {
                proc.kill("SIGKILL"); // paksa berhenti
            } catch (err) {
                console.error("Failed to kill process:", err);
            }
        });

        // Bersihkan array global
        global.runningProcesses = [];

        bot.sendMessage(chatId, `
☠️ Semua proses yang berjalan telah dihentikan!
`);
    });

};