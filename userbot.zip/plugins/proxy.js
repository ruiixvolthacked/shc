const { exec } = require("child_process");
const path = require("path");
const config = require("../config");

module.exports = (bot) => {

    if (!global.runningProcesses) global.runningProcesses = [];

    bot.onText(/\PROXYHTTP/, (msg) => {

        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (userId !== config.ownerId)
            return bot.sendMessage(chatId, "Access denied.");

        const toolPath = path.join(__dirname, "../tools/proxy.js");

        bot.sendMessage(chatId, "Start scrape please wait...");

        const child = exec(`node "${toolPath}"`);

        global.runningProcesses.push(child);

        let outputBuffer = "";

        child.stdout.on("data", (chunk) => {
            outputBuffer += chunk.toString();
        });

        child.on("close", async () => {

            try {
                const result = JSON.parse(outputBuffer.trim());

                await bot.sendMessage(chatId,
                    `Succesfully
Total mentah: ${result.totalRaw}
Total ipunik: ${result.totalUnique}
File: tools/proxy.txt`
                );

            } catch (err) {
                bot.sendMessage(chatId, "Scrape parse error.");
            }

            global.runningProcesses =
                global.runningProcesses.filter(p => p !== child);

        });

        child.on("error", (err) => {
            bot.sendMessage(chatId, `Process error: ${err.message}`);
            global.runningProcesses =
                global.runningProcesses.filter(p => p !== child);
        });

    });

};