const os = require("os");
const pidusage = require("pidusage");
const config = require("../config");

module.exports = (bot) => {

    if (!global.runningProcesses) global.runningProcesses = [];

    bot.onText(/\/ping/, async (msg) => {

        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (userId !== config.ownerId)
            return bot.sendMessage(chatId, "Access denied.");

        try {
            // ===== Sistem Info =====
            const totalMem = os.totalmem();
            const freeMem = os.freemem();
            const usedMem = totalMem - freeMem;
            const cpuCount = os.cpus().length;
            const load = os.loadavg().map(l => l.toFixed(2)).join(", ");
            const uptimeSys = Math.floor(os.uptime() / 60); // menit

            // ===== Bot Process Info =====
            const stats = await pidusage(process.pid);
            const usedMemProcMB = (stats.memory / 1024 / 1024).toFixed(2);
            const cpuProcPercent = stats.cpu.toFixed(2);
            const taskCount = global.runningProcesses.length;

            // ===== Build Message =====
            const message = `
📊 Bot & System Status
--------------------------
💻 Platform      : ${os.platform()} ${os.arch()}
🕒 System Uptime : ${uptimeSys} min
⚙️ CPU Cores     : ${cpuCount}
⚡ Load Avg       : ${load}
🧠 RAM Usage     : ${(usedMem / 1024 / 1024).toFixed(2)} MB / ${(totalMem / 1024 / 1024).toFixed(2)} MB
--------------------------
🤖 Bot PID       : ${process.pid}
🌐 Bot Task      : ${taskCount}
⚡ Bot CPU        : ${cpuProcPercent} %
🧠 Bot Memory    : ${usedMemProcMB} MB
--------------------------
✅ Bot is alive!
            `;

            bot.sendMessage(chatId, message); // plain text

        } catch (err) {
            bot.sendMessage(chatId, "Failed to get system info: " + err.message);
        }

    });

};