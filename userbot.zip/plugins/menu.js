const config = require("../config")
module.exports = (bot) => {
    bot.onText(/\SHOW/, async (msg) => {
        const chatId = msg.chat.id
        const userId = msg.from.id
        // kalau mau public, hapus block ini
        if (userId !== config.ownerId)
            return bot.sendMessage(chatId, "Access denied.")
        const videoUrl = "https://image2url.com/r2/default/videos/1770017278191-cad2e2d2-0554-4260-9786-a0b9372b145d.mp4" // ganti>
        const caption = `
╭━ 「 🧸ruiixh4x0r_ 」
┃╭──────────────────
┃┃愛  PROXY SCRAPE
┃┃愛  H2
┃┃愛  TO
┃┃愛  RAW
┃┃愛  STORMX
┃┃愛  KILL ALL TASK
┃╰──────────────────
╰━━━━━━━━━━━━━━━━━━━━
`
        // kirim video + caption
        await bot.sendVideo(chatId, videoUrl, {
            caption: caption
        })
    })
}