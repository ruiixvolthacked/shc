module.exports = {
    api_id: 31556842, // isi dari my.telegram.org
    api_hash: "9bca0fccc5fc24c878049ba888296dc3",
    ownerId: 7079195921 // user id telegram kamu
}